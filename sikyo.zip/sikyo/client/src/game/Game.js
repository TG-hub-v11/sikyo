import * as THREE from 'three';
import { buildArena } from '../scene/arena.js';
import { createAvatar } from '../player/avatar.js';
import { getCharacterSkills } from '../skills/characterSkills.js';
export class Game {
  constructor(canvas, net) {
    this.canvas = canvas; this.net = net;
    this.players = new Map(); this.meId = null;
    this.scores = { red: 0, blue: 0 };
    this.keys = {}; this.joy = { x: 0, y: 0 };
    this.sound = true; this.practice = false; this.lastSend = 0;
    this.clock = new THREE.Clock();
    this.fx = new THREE.Group();
    this.initThree(); this.bindInput(); this.bindNet();
    this.animate = this.animate.bind(this);
    requestAnimationFrame(this.animate);
  }
  initThree() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(innerWidth, innerHeight);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 300);
    this.camera.position.set(0, 26, 34); this.camera.lookAt(0, 0, 0);
    this.arena = buildArena(this.scene);
    this.scene.add(this.fx);
    this.runeMeshes = new Map(); // id -> mesh
    this.stoneMeshes = new Map();
    this.bombMeshes = new Map();
    this.runes = [];
    this.particles = [];
    addEventListener('resize', () => {
      this.camera.aspect = innerWidth / innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(innerWidth, innerHeight);
    });
  }
  bindInput() {
    addEventListener('keydown', (e) => {
      if (e.code === 'Space') e.preventDefault();
      if (e.repeat) return;
      this.keys[e.code] = true;
      if (e.code === 'KeyE') this.doRescue();
      if (e.code === 'KeyF') this.doSkill();
      if (e.code === 'Space') this.doDash();
      // Character-specific skills (1-4)
      if (e.code === 'Digit1') this.doCharacterSkill(0);
      if (e.code === 'Digit2') this.doCharacterSkill(1);
      if (e.code === 'Digit3') this.doCharacterSkill(2);
      if (e.code === 'Digit4') this.doCharacterSkill(3);
    });
    addEventListener('keyup', (e) => { this.keys[e.code] = false; });
    const joy = document.getElementById('joystick');
    const stick = document.getElementById('stick');
    let jid = null;
    joy.addEventListener('touchstart', (e) => { jid = e.changedTouches[0].identifier; }, { passive: true });
    addEventListener('touchmove', (e) => {
      for (const t of e.changedTouches) if (t.identifier === jid) {
        const r = joy.getBoundingClientRect();
        this.joy.x = (t.clientX - (r.left + 60)) / 40;
        this.joy.y = (t.clientY - (r.top + 60)) / 40;
        stick.style.transform = 'translate(' + this.joy.x * 34 + 'px,' + this.joy.y * 34 + 'px)';
      }
    }, { passive: true });
    addEventListener('touchend', () => { this.joy.x = 0; this.joy.y = 0; stick.style.transform = ''; });
    if ('ontouchstart' in window) document.body.classList.add('touch');
    document.getElementById('btn-rescue').onclick = () => this.doRescue();
    document.getElementById('btn-skill').onclick = () => this.doSkill();
    document.getElementById('btn-dash').onclick = () => this.doDash();
    document.getElementById('btn-pause').onclick = () => this.toast('Pause — Diskartehan mo!');
    document.getElementById('btn-sound').onclick = (e) => {
      this.sound = !this.sound; e.target.textContent = this.sound ? '🔊' : '🔇';
    };
    this._dashCdUntil = 0; this._skillMsg = '';
  }
  fxGroup() { return this.fx; }
  createParticles(x, y, z, color, count = 10, spread = 0.5) {
    const particles = [];
    const geom = new THREE.SphereGeometry(0.08, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1 });
    for (let i = 0; i < count; i++) {
      const p = new THREE.Mesh(geom, mat.clone());
      p.position.set(
        x + (Math.random() - 0.5) * spread,
        y + Math.random() * spread,
        z + (Math.random() - 0.5) * spread
      );
      p.userData = {
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 3,
          Math.random() * 2 + 1,
          (Math.random() - 0.5) * 3
        ),
        life: 1.0
      };
      this.fx.add(p);
      particles.push(p);
    }
    this.particles.push(...particles);
  }
  updateParticles(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.userData.life -= dt * 2;
      if (p.userData.life <= 0) {
        this.fx.remove(p);
        this.particles.splice(i, 1);
        continue;
      }
      p.position.add(p.userData.vel.clone().multiplyScalar(dt));
      p.userData.vel.y -= 5 * dt; // gravity
      p.material.opacity = p.userData.life;
      p.scale.setScalar(p.userData.life);
    }
  }
  bindNet() {
    this.net.on('match:tick', (s) => this.onTick(s));
    this.net.on('player:tagged', (d) => {
      this.toast(d.text);
      const t = this.players.get(d.target?.id);
      if (t) {
        t.avatar.setCaptured(true);
        t.avatar.pop?.();
        this.createParticles(t.avatar.group.position.x, 1.5, t.avatar.group.position.z, 0xE63946, 20, 1.0);
        this.beep(330);
      }
      const a = this.players.get(d.tagger?.id);
      if (a) a.avatar.pop?.();
    });
    this.net.on('player:rescued', (d) => {
      this.toast(d.text);
      (d.freed || []).forEach(f => this.players.get(f.id)?.avatar.clearMood());
      const r = this.players.get(d.rescuer?.id);
      if (r) r.avatar.hop?.();
      this.beep(880);
    });
    this.net.on('match:end', (d) => {
      for (const e of this.players.values()) {
        e.avatar.celebrate?.(e.data.team === d.winner);
      }
    });
    this.net.on('match:rematch', () => {
      for (const e of this.players.values()) e.avatar.clearMood?.();
    });
    this.net.on('rescue:prompt', () => {
      const me = this.players.get(this.meId);
      if (me && me.data.state === 'free') me.avatar.hop?.();
    });
    this.net.on('base:captured', (d) => {
      this.scores = d.scores; this.updateHUD(); this.toast(d.text); this.beep(660);
    });
    this.net.on('rune:spawned', (d) => this.syncRunes(d.runes || []));
    this.net.on('rune:taken', (d) => {
      if (d?.by) this.toast(d.by + ' nakakuha ng rune! ' + (d.type || ''));
      this.runeMeshes.delete(d?.id);
    });
    this.net.on('rune:got', (d) => {
      this.mySkill = d?.skill || null; this.mySkillCount = d?.count || 0;
      const names = { swift: '⚡ Sigla: +bilis 8s!', dash: '💨 Harurot: dash ready!', stone: '🪨 Bato: F para bumato!', bomb: '💣 Paputok: F para maghagis!', shield: '🛡️ Kalasag: block 1 tag!', ghost: '👻 Multo: 5s di mahuli!' };
      this.toast(names[d?.type] || 'Rune nakuha!');
      this.beep(980);
      this.updateSkillHUD();
    });
    this.net.on('stone:thrown', () => this.beep(500));
    this.net.on('bomb:thrown', () => this.beep(500));
    this.net.on('bomb:boom', (d) => {
      this.boomFx(d.x, d.z);
      this.createParticles(d.x, 0.5, d.z, 0xFF4500, 30, 2.0);
      this.createParticles(d.x, 0.5, d.z, 0xFFFF00, 20, 1.5);
      if (d?.stunned?.some(s => s.id === this.meId)) {
        this.toast('Na-stun ka! Takbo pag gising! 💣');
        document.body.classList.add('stunned');
        setTimeout(() => document.body.classList.remove('stunned'), 2000);
      }
      else if (d?.text) this.toast(d.text);
      this.beep(180);
    });
    this.net.on('player:dashed', (d) => {
      const e = this.players.get(d?.id);
      if (e && d) { e.tx = d.x; e.tz = d.z; e.avatar.dash?.(); }
      if (d?.id !== this.meId && d?.text) this.toast(d.text);
    });
    this.net.on('shield:blocked', (d) => {
      this.toast(d?.text || 'Nasalag! 🛡️');
      const e = this.players.get(d?.id);
      if (e) e.avatar.pop?.();
      this.beep(700);
    });
  }
  ensure(id, nick, team, species = 'fox') {
    let e = this.players.get(id);
    if (!e) {
      const av = createAvatar(team, nick, species);
      this.scene.add(av.group);
      e = { data: { id, nick, team, species, x: 0,
        z: team === 'red' ? 22 : -22, rot: 0, state: 'free', seq: 0 }, avatar: av, tx: 0, tz: 0 };
      this.players.set(id, e);
    } else if (e.avatar.species !== species || e.data.team !== team || e.data.nick !== nick) {
      // species/team switch (lobby change or server-assigned): rebuild avatar
      this.scene.remove(e.avatar.group);
      const av = createAvatar(team, nick, species);
      this.scene.add(av.group);
      e.avatar = av;
      Object.assign(e.data, { nick, team, species });
    }
    return e;
  }
  previewSpecies(species) {
    this.mySpecies = species;
    const e = this.ensure('me', 'Ikaw', 'red', species);
    e.data.x = 0; e.data.z = 10; e.tx = 0; e.tz = 10;
    e.data.rot = 0; e.avatar.clearMood(); e.avatar.hop();
  }
  startPractice(nick) {
    // 5v5: ikaw + 4 AI kakampi (red) vs 5 AI kalaban (blue)
    for (const [id, e] of [...this.players]) {
      if (id !== 'me') { this.scene.remove(e.avatar.group); this.players.delete(id); }
    }
    this.practice = true; this.meId = 'me';
    this._pSeq = 1;
    this._pScore = { red: 0, blue: 0 };
    this._pOver = false;
    this._botThink = 0;
    this._pRunes = []; this._pRuneSeq = 1; this._lastRune = 0;
    this._pStones = []; this._pStoneSeq = 1;
    this._pBombs = []; this._pBombSeq = 1;
    const chars = ['naruto', 'goku', 'saitama', 'gojo', 'killua'];
    this.ensure('me', nick || 'Kabayan', 'red', this.mySpecies || 'naruto');
    this.ensure('ally1', 'Naruto', 'red', 'naruto');
    this.ensure('ally2', 'Goku', 'red', 'goku');
    this.ensure('ally3', 'Saitama', 'red', 'saitama');
    this.ensure('ally4', 'Gojo', 'red', 'gojo');
    this.ensure('foe1', 'Killua', 'blue', 'killua');
    this.ensure('foe2', 'Naruto', 'blue', 'naruto');
    this.ensure('foe3', 'Goku', 'blue', 'goku');
    this.ensure('foe4', 'Saitama', 'blue', 'saitama');
    this.ensure('foe5', 'Gojo', 'blue', 'gojo');
    const allies = ['me', 'ally1', 'ally2', 'ally3', 'ally4'];
    allies.forEach((id, i) => {
      const e = this.players.get(id);
      const a = (i / 5) * Math.PI * 2;
      e.data.x = Math.cos(a) * 2.5; e.data.z = 22 + Math.sin(a) * 2.5;
      e.data.seq = 0; e.data.wasInBase = true; e.data.state = 'free';
      e.data.rot = Math.PI; e.tx = e.data.x; e.tz = e.data.z;
      e.data.jumping = false; e.data.jumpProgress = 0;
      e.data.stunUntil = 0; e.data.swiftUntil = 0; e.data.shieldUntil = 0; e.data.shieldCharges = 0; e.data.ghostUntil = 0;
      e.data.skill = null; e.data.skillCount = 0;
      e.avatar.setCaptured(false);
    });
    const foeSpots = [[0, -10], [-8, -4], [8, -4], [-5, 6], [5, 6]];
    foeSpots.forEach((s, i) => {
      const e = this.players.get('foe' + (i + 1));
      e.data.x = s[0]; e.data.z = s[1];
      e.data.seq = this._pSeq++; e.data.wasInBase = false; e.data.state = 'free';
      e.data.rot = 0; e.tx = s[0]; e.tz = s[1];
      e.data.jumping = false; e.data.jumpProgress = 0;
      e.data.stunUntil = 0; e.data.swiftUntil = 0; e.data.shieldUntil = 0; e.data.shieldCharges = 0; e.data.ghostUntil = 0;
      e.data.skill = null; e.data.skillCount = 0;
      e.avatar.setCaptured(false);
      e.wp = null; e.think = Math.random() * 2;
    });
    this.players.get('ally1').think = 0; this.players.get('ally2').think = 0.5;
    this.players.get('ally3').think = 1; this.players.get('ally4').think = 1.5;
    document.getElementById('hud').classList.remove('hidden');
    this.scores = this._pScore;
    this.updateHUD();
    this.toast('5v5 Practice! Ikaw + 4 kakampi vs 5 kalaban. Lumabas para manghuli — nahuli, nakakahuli!');
  }
  inBaseLocal(x, z, team) {
    const bz = team === 'red' ? 22 : -22;
    return Math.hypot(x - 0, z - bz) <= 5;
  }
  trackDepartureLocal(e) {
    const inB = this.inBaseLocal(e.data.x, e.data.z, e.data.team);
    if (e.data.wasInBase && !inB) {
      e.data.seq = this._pSeq++;
      e.data.wasInBase = false;
      if (e.data.id === 'me') this.toast('Umalis ka — ikaw hunter ngayon! Habulin si Bot!');
    }
    if (inB && !e.data.wasInBase) {
      e.data.wasInBase = true; e.data.seq = 0;
      if (e.data.id === 'me') { this.toast('Nag-reset ka sa base! Lumabas ulit para makataya.'); this.updateHUD(); }
    } else if (!inB) e.data.wasInBase = false;
  }
  onTick(s) {
    this.scores = s.scores;
    document.getElementById('match-timer').textContent = fmtTime(s.timeLeft);
    document.getElementById('match-target').textContent = 'First to ' + s.target;
    for (const p of s.players) {
      const wasCap = this.players.get(p.id)?.data.state === 'captured';
      const e = this.ensure(p.id, p.nick, p.team, p.species || 'fox');
      Object.assign(e.data, p); e.tx = p.x; e.tz = p.z;
      if (p.state !== 'captured' && wasCap) e.avatar.clearMood();
      e.avatar.setCaptured(p.state === 'captured');
      e.avatar.setJump(p.jumping || false, p.jumpProgress || 0);
    }
    // hunter ring: dilaw lang kung may mas-nauna (mas maliit seq) na kalaban sa labas
    const free = s.players.filter(p => p.state === 'free' && p.seq);
    for (const p of s.players) {
      const e = this.players.get(p.id); if (!e) continue;
      if (p.state !== 'free' || !p.seq) { e.avatar.setCanTag(false); continue; }
      const hunter = free.some(o => o.team !== p.team && p.seq > o.seq);
      e.avatar.setCanTag(hunter);
    }
    this.updateHUD();
    const me = this.players.get(this.meId);
    if (me) {
      const bz = me.data.team === 'red' ? 22 : -22;
      const threat = s.players.some(p => p.team !== me.data.team && p.state === 'free' &&
        Math.hypot(p.x, p.z - bz) < 12);
      document.getElementById('base-warn').classList.toggle('hidden', !threat);
    }
  }
  setMe(id) { this.meId = id || this.net.id; }
  doRescue() { this.net.send('player:rescue', {}); if (this.practice) this.practiceRescue(); }
  doSkill() {
    this.net.send('player:skill', {});
    if (this.practice) this.practiceSkill();
  }
  doCharacterSkill(index) {
    const me = this.players.get(this.meId);
    if (!me) return;

    const character = me.data.species || 'naruto';
    const skills = getCharacterSkills(character);

    if (index < 0 || index >= skills.skills.length) return;

    const skill = skills.skills[index];
    this.useCharacterSkill(skill, me);
  }
  useCharacterSkill(skill, player) {
    const me = this.players.get(this.meId);
    if (!me || me.data.state !== 'free') return;

    // Check cooldown
    const now = Date.now();
    const cooldownKey = `_${skill.id}Cooldown`;
    if (this[cooldownKey] && this[cooldownKey] > now) {
      this.toast(`${skill.name} on cooldown!`);
      return;
    }

    // Set cooldown
    this[cooldownKey] = now + (skill.cooldown * 1000);

    // Execute skill based on type
    switch (skill.type) {
      case 'aoe':
        this.executeAOESkill(skill, me);
        break;
      case 'buff':
        this.executeBuffSkill(skill, me);
        break;
      case 'teleport':
        this.executeTeleportSkill(skill, me);
        break;
      case 'beam':
        this.executeBeamSkill(skill, me);
        break;
      case 'melee':
        this.executeMeleeSkill(skill, me);
        break;
      case 'shield':
        this.executeShieldSkill(skill, me);
        break;
      case 'push':
      case 'pull':
        this.executeForceSkill(skill, me);
        break;
      case 'dash':
        this.executeDashSkill(skill, me);
        break;
      case 'stealth':
        this.executeStealthSkill(skill, me);
        break;
      default:
        this.executeDefaultSkill(skill, me);
    }

    this.toast(`${skill.name}! ${skill.description}`);
    this.beep(800);
    player.avatar.skillCast(skill.id);
    this.createParticles(me.avatar.group.position.x, 1.5, me.avatar.group.position.z, skill.color, 20, 1.2);
  }
  executeAOESkill(skill, me) {
    // AOE stun around player
    const pos = me.avatar.group.position;
    this.createParticles(pos.x, 0.5, pos.z, skill.color, 30, 3);
    // In practice mode, stun nearby enemies
    if (this.practice) {
      [...this.players.values()].forEach(p => {
        if (p.data.team !== me.data.team && p.data.state === 'free') {
          const dist = Math.hypot(p.data.x - pos.x, p.data.z - pos.z);
          if (dist < skill.range) {
            p.data.stunUntil = Date.now() + 2000;
            p.avatar.setFx({ stun: true });
            setTimeout(() => p.avatar.setFx({}), 2000);
          }
        }
      });
    }
  }
  executeBuffSkill(skill, me) {
    // Speed boost or immunity
    me.data.swiftUntil = Date.now() + 5000;
    me.avatar.setFx({ swift: true });
    setTimeout(() => {
      me.avatar.setFx({});
      me.data.swiftUntil = 0;
    }, 5000);
  }
  executeTeleportSkill(skill, me) {
    // Teleport forward
    const dx = Math.sin(me.data.rot) * skill.range;
    const dz = Math.cos(me.data.rot) * skill.range;
    me.data.x = Math.max(-28, Math.min(28, me.data.x + dx));
    me.data.z = Math.max(-28, Math.min(28, me.data.z + dz));
    me.tx = me.data.x;
    me.tz = me.data.z;
    this.createParticles(me.data.x, 1, me.data.z, skill.color, 15, 1);
  }
  executeBeamSkill(skill, me) {
    // Energy beam (visual effect)
    const pos = me.avatar.group.position;
    const beamEnd = {
      x: pos.x + Math.sin(me.data.rot) * skill.range,
      z: pos.z + Math.cos(me.data.rot) * skill.range
    };
    // Create beam particles
    for (let i = 0; i < 20; i++) {
      const t = i / 20;
      const px = pos.x + (beamEnd.x - pos.x) * t;
      const pz = pos.z + (beamEnd.z - pos.z) * t;
      this.createParticles(px, 1.5, pz, skill.color, 3, 0.5);
    }
  }
  executeMeleeSkill(skill, me) {
    // Short range melee attack
    const pos = me.avatar.group.position;
    this.createParticles(pos.x, 1, pos.z, skill.color, 15, 1.5);
    if (this.practice) {
      [...this.players.values()].forEach(p => {
        if (p.data.team !== me.data.team && p.data.state === 'free') {
          const dist = Math.hypot(p.data.x - pos.x, p.data.z - pos.z);
          if (dist < skill.range) {
            p.data.stunUntil = Date.now() + 1500;
            p.avatar.setFx({ stun: true });
            setTimeout(() => p.avatar.setFx({}), 1500);
          }
        }
      });
    }
  }
  executeShieldSkill(skill, me) {
    // Invincibility shield
    me.data.shieldUntil = Date.now() + 4000;
    me.data.shieldCharges = 1;
    me.avatar.setFx({ shield: true });
    setTimeout(() => {
      me.avatar.setFx({});
      me.data.shieldUntil = 0;
      me.data.shieldCharges = 0;
    }, 4000);
  }
  executeForceSkill(skill, me) {
    // Push or pull enemies
    const pos = me.avatar.group.position;
    this.createParticles(pos.x, 1, pos.z, skill.color, 20, 2);
    if (this.practice) {
      [...this.players.values()].forEach(p => {
        if (p.data.team !== me.data.team && p.data.state === 'free') {
          const dist = Math.hypot(p.data.x - pos.x, p.data.z - pos.z);
          if (dist < skill.range) {
            const dir = skill.type === 'push' ? 1 : -1;
            const angle = Math.atan2(p.data.x - pos.x, p.data.z - pos.z);
            p.data.x += Math.sin(angle) * 5 * dir;
            p.data.z += Math.cos(angle) * 5 * dir;
            p.tx = p.data.x;
            p.tz = p.data.z;
          }
        }
      });
    }
  }
  executeDashSkill(skill, me) {
    // Dash through enemies
    const dx = Math.sin(me.data.rot) * skill.range;
    const dz = Math.cos(me.data.rot) * skill.range;
    me.data.x = Math.max(-28, Math.min(28, me.data.x + dx));
    me.data.z = Math.max(-28, Math.min(28, me.data.z + dz));
    me.tx = me.data.x;
    me.tz = me.data.z;
    me.avatar.dash();
    this.createParticles(me.data.x, 1, me.data.z, skill.color, 25, 2);
  }
  executeStealthSkill(skill, me) {
    // Invisibility
    me.data.ghostUntil = Date.now() + 3000;
    me.avatar.setFx({ ghost: true });
    setTimeout(() => {
      me.avatar.setFx({});
      me.data.ghostUntil = 0;
    }, 3000);
  }
  executeDefaultSkill(skill, me) {
    // Default skill execution
    const pos = me.avatar.group.position;
    this.createParticles(pos.x, 1.5, pos.z, skill.color, 15, 1);
  }
  practiceSkill() {
    const me = this.players.get('me');
    if (!me || me.data.state !== 'free' || this._pOver) return;
    const now = Date.now();
    if ((me.data.stunUntil || 0) > now || !me.data.seq) return;
    if (me.data.skill === 'stone' && me.data.skillCount > 0) {
      me.data.skillCount -= 1;
      if (me.data.skillCount <= 0) me.data.skill = null;
      this._pStones.push({ id: 's' + (this._pStoneSeq++), ownerId: 'me', team: 'red',
        x: me.data.x, z: me.data.z, dx: Math.sin(me.data.rot), dz: Math.cos(me.data.rot) });
      me.avatar.skillCast('stone');
      this.beep(500);
    } else if (me.data.skill === 'bomb' && me.data.skillCount > 0) {
      me.data.skillCount -= 1;
      if (me.data.skillCount <= 0) me.data.skill = null;
      const d = 6;
      const bx = Math.max(-28, Math.min(28, me.data.x + Math.sin(me.data.rot) * d));
      const bz = Math.max(-28, Math.min(28, me.data.z + Math.cos(me.data.rot) * d));
      this._pBombs.push({ id: 'b' + (this._pBombSeq++), ownerId: 'me', team: 'red',
        x: bx, z: bz, explodeAt: now + 800 });
      me.avatar.skillCast('bomb');
      this.beep(500);
    }
    this.mySkill = me.data.skill; this.mySkillCount = me.data.skillCount;
    this.updateSkillHUD();
  }
  pTail(team) {
    const caps = [...this.players.values()].filter(e => e.data.team === team && e.data.state === 'captured');
    if (!caps.length) return null;
    caps.sort((a, b) => (a.data.capturedAt || 0) - (b.data.capturedAt || 0));
    return caps[caps.length - 1];
  }
  pFreeCaptured(rescuer) {
    const team = rescuer.data.team;
    const freed = [...this.players.values()].filter(e => e.data.team === team && e.data.state === 'captured');
    freed.forEach((e, i) => {
      e.data.state = 'free'; e.data.capturedAt = 0;
      const a = (i / 6) * Math.PI * 2;
      e.data.x = Math.cos(a) * 2.5;
      e.data.z = (team === 'red' ? 22 : -22) + Math.sin(a) * 2.5;
      e.data.seq = 0; e.data.wasInBase = true;
      e.tx = e.data.x; e.tz = e.data.z;
      e.avatar.setCaptured(false);
    });
    if (rescuer.data.id === 'me' || freed.some(f => f.data.id === 'me')) this.updateHUD();
    return freed;
  }
  practiceRescue() {
    const me = this.players.get('me'); if (!me || me.data.state !== 'free' || this._pOver) return;
    const tail = this.pTail('red');
    if (!tail) return;
    const d = Math.hypot(tail.data.x - me.data.x, tail.data.z - me.data.z);
    if (d < 3.2) {
      const freed = this.pFreeCaptured(me);
      freed.forEach(f => f.avatar.clearMood());
      me.avatar.hop?.();
      this.toast('Sagipin ang tropa! +' + freed.length + ' rescued 🎉');
      this.beep(880);
    }
  }
  toast(t) {
    const el = document.getElementById('toast');
    el.textContent = t; el.classList.remove('hidden');
    clearTimeout(this._tt); this._tt = setTimeout(() => el.classList.add('hidden'), 2200);
  }
  beep(f) {
    if (!this.sound) return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = this._ac || (this._ac = new Ctx());
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = f || 440; o.connect(g); g.connect(ctx.destination);
      o.start(); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      o.stop(ctx.currentTime + 0.25);
    } catch (e) {}
  }
  updateHUD() {
    document.getElementById('score-red').textContent = this.scores.red;
    document.getElementById('score-blue').textContent = this.scores.blue;
    const me = this.players.get(this.meId);
    if (me) {
      const d = me.data;
      let role = 'SAFE SA BASE';
      if (d.state === 'captured') role = 'CAPTURED — hintay rescue!';
      else if (!d.seq) role = 'NASA BASE — lumabas para maglaro';
      else {
        // hunter kung may kalaban kang mas nauna (mas maliit seq) sa labas
        let prey = false, hunter = false;
        for (const e of this.players.values()) {
          if (e.data.team === d.team || e.data.state !== 'free' || !e.data.seq) continue;
          if (d.seq > e.data.seq) hunter = true;
          if (d.seq < e.data.seq) prey = true;
        }
        if (hunter && prey) role = 'HUNTER + TAYA — diskartehan mo!';
        else if (hunter) role = 'NAKAKAHULI — habulin mo sila!';
        else if (prey) role = 'TAYA KA — bumalik sa base para mag-reset!';
        else role = 'FREE — walang kalaban sa labas';
      }
      document.getElementById('me-info').textContent = d.nick + ' | ' + d.team.toUpperCase() + ' | ' + role;
    }
  }
  readInput() {
    let dx = 0, dz = 0;
    if (this.keys.KeyW || this.keys.ArrowUp) dz -= 1;
    if (this.keys.KeyS || this.keys.ArrowDown) dz += 1;
    if (this.keys.KeyA || this.keys.ArrowLeft) dx -= 1;
    if (this.keys.KeyD || this.keys.ArrowRight) dx += 1;
    dx += this.joy.x; dz += this.joy.y;
    const sprint = !!(this.keys.ShiftLeft || this.keys.ShiftRight);
    const jump = this.keys.Space;
    const m = Math.hypot(dx, dz);
    if (m > 1) { dx /= m; dz /= m; }
    return { dx: dx, dz: dz, sprint: sprint, jump: jump };
  }
  animate() {
    requestAnimationFrame(this.animate);
    const t = this.clock.getElapsedTime();
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.arena.update(t);
    if (this.practice) this.practiceTick();
    this.updateParticles(dt);
    const now = performance.now();
    const inp = this.readInput();
    if (now - this.lastSend > 50 && this.meId && (inp.dx || inp.dz || inp.sprint || inp.jump)) {
      this.lastSend = now;
      this.net.send('player:move', inp);
      if (this.practice) this.moveLocal('me', inp, 1 / 60);
    } else if (this.practice && (inp.dx || inp.dz)) this.moveLocal('me', inp, 1 / 60);
    for (const e of this.players.values()) {
      const g = e.avatar.group;
      if (!(this.practice && e.data.id === 'me')) {
        g.position.x += (e.tx - g.position.x) * 0.35;
        g.position.z += (e.tz - g.position.z) * 0.35;
      } else g.position.set(e.data.x, 0, e.data.z);
      // Smooth rotation interpolation
      const targetRot = e.data.rot || 0;
      let rotDiff = targetRot - g.rotation.y;
      while (rotDiff > Math.PI) rotDiff -= Math.PI * 2;
      while (rotDiff < -Math.PI) rotDiff += Math.PI * 2;
      g.rotation.y += rotDiff * 0.3;
      e.avatar.anim(t, true, false);
      // Spawn particles on jump landing
      if (e.avatar._dustFx > 0.8 && !e.avatar._spawnedDust) {
        this.createParticles(g.position.x, 0.1, g.position.z, 0xE8E0C8, 8, 0.6);
        e.avatar._spawnedDust = true;
      }
      if (e.avatar._dustFx <= 0) e.avatar._spawnedDust = false;
      // Skill cast particles
      if (e.avatar._skillFx > 0.9 && !e.avatar._skillParticleSpawned) {
        const skillColors = {
          swift: 0xFFFF00,
          dash: 0x00FFFF,
          stone: 0x8B4513,
          bomb: 0xFF4500,
          shield: 0x00FF00,
          ghost: 0x9932CC
        };
        const color = skillColors[e.avatar._skillType] || 0xFFFFFF;
        this.createParticles(g.position.x, 1.5, g.position.z, color, 15, 1.0);
        e.avatar._skillParticleSpawned = true;
      }
      if (e.avatar._skillFx <= 0) e.avatar._skillParticleSpawned = false;
    }
    const me = this.players.get(this.meId);
    if (me) {
      const p = me.avatar.group.position;
      const off = me.data.team === 'red' ? 14 : -14;
      this.camera.position.lerp(new THREE.Vector3(p.x, 24, p.z + off), 0.05);
      this.camera.lookAt(p.x, 0, p.z);
    } else {
      this.camera.position.set(Math.sin(t * 0.1) * 40, 26, Math.cos(t * 0.1) * 40);
      this.camera.lookAt(0, 0, 0);
    }
    this.renderer.render(this.scene, this.camera);
  }
  moveLocal(id, inp, dt) {
    const e = this.players.get(id); if (!e || e.data.state !== 'free') return;
    const sp = 8 * (inp.sprint ? 1.5 : 1);
    e.data.x = Math.max(-28, Math.min(28, e.data.x + inp.dx * sp * dt));
    e.data.z = Math.max(-28, Math.min(28, e.data.z + inp.dz * sp * dt));
    if (Math.hypot(inp.dx, inp.dz) > 0.05) e.data.rot = Math.atan2(inp.dx, inp.dz);
    // Handle jump in practice mode
    if (inp.jump && !e.data.jumping) {
      e.data.jumping = true;
      e.data.jumpStartedAt = Date.now();
    }
    if (e.data.jumping) {
      const jumpElapsed = (Date.now() - e.data.jumpStartedAt) / 1000;
      if (jumpElapsed >= 0.6) {
        e.data.jumping = false;
      }
      e.data.jumpProgress = Math.min(1, jumpElapsed / 0.6);
    } else {
      e.data.jumpProgress = 0;
    }
    this.trackDepartureLocal(e);
    e.tx = e.data.x; e.tz = e.data.z;
  }
  practiceTick() {
    const me = this.players.get('me'); if (!me || this._pOver) return;
    this.trackDepartureLocal(me);
    const dt = 1 / 60, nowT = performance.now() / 1000;
    const now = Date.now();
    // Rune spawning (mirror server logic)
    if (!this._lastRune || now - this._lastRune > 10000) {
      this._lastRune = now;
      if (this._pRunes.length < 3) {
        const spots = [{ x: -12, z: 0 }, { x: 12, z: 0 }, { x: 0, z: 8 }, { x: 0, z: -8 }, { x: -7, z: 12 }, { x: 7, z: -12 }];
        const occupied = new Set(this._pRunes.map(r => r.spot));
        const free = spots.map((s, i) => i).filter(i => !occupied.has(i));
        if (free.length) {
          const si = free[Math.floor(Math.random() * free.length)];
          const spot = spots[si];
          const types = ['swift', 'dash', 'stone', 'bomb', 'shield', 'ghost'];
          const type = types[Math.floor(Math.random() * types.length)];
          this._pRunes.push({ id: 'r' + (this._pRuneSeq++), spot: si, x: spot.x, z: spot.z, type });
          this.syncRunes(this._pRunes);
        }
      }
    }
    // Rune pickup
    for (const p of this.players.values()) {
      if (p.data.state !== 'free' || !p.data.seq) continue;
      const hit = this._pRunes.find(r => Math.hypot(r.x - p.data.x, r.z - p.data.z) < 1.4);
      if (hit) {
        const idx = this._pRunes.indexOf(hit);
        if (idx >= 0) this._pRunes.splice(idx, 1);
        this.toast(p.data.nick + ' nakakuha ng rune! ' + hit.type);
        this.runeMeshes.delete(hit.id);
        if (hit.type === 'swift') p.data.swiftUntil = now + 8000;
        else if (hit.type === 'dash') { p.data.dashReadyAt = 0; }
        else if (hit.type === 'stone') { p.data.skill = 'stone'; p.data.skillCount = 1; }
        else if (hit.type === 'bomb') { p.data.skill = 'bomb'; p.data.skillCount = 1; }
        else if (hit.type === 'shield') { p.data.shieldUntil = now + 10000; p.data.shieldCharges = 1; }
        else if (hit.type === 'ghost') p.data.ghostUntil = now + 5000;
        if (p.data.id === 'me') {
          const names = { swift: '⚡ Sigla: +bilis 8s!', dash: '💨 Harurot: dash ready!', stone: '🪨 Bato: F para bumato!', bomb: '💣 Paputok: F para maghagis!', shield: '🛡️ Kalasag: block 1 tag!', ghost: '👻 Multo: 5s di mahuli!' };
          this.toast(names[hit.type] || 'Rune nakuha!');
          this.mySkill = p.data.skill; this.mySkillCount = p.data.skillCount;
          this.updateSkillHUD();
        }
        this.syncRunes(this._pRunes);
      }
    }
    // Update player FX states
    for (const e of this.players.values()) {
      const fx = {
        stun: (e.data.stunUntil || 0) > now,
        swift: (e.data.swiftUntil || 0) > now,
        shield: (e.data.shieldUntil || 0) > now && (e.data.shieldCharges || 0) > 0,
        ghost: (e.data.ghostUntil || 0) > now
      };
      e.avatar.setFx(fx);
    }
    // Stone projectile update
    const stoneStep = 24 * dt;
    for (const s of [...this._pStones]) {
      s.x += s.dx * stoneStep; s.z += s.dz * stoneStep;
      if (Math.abs(s.x) > 30 || Math.abs(s.z) > 30) {
        this._pStones = this._pStones.filter(x => x !== s); continue;
      }
      const owner = this.players.get(s.ownerId);
      for (const t of this.players.values()) {
        if (!owner || t.data.team === s.team || t.data.state !== 'free' || !t.data.seq) continue;
        if (Math.hypot(t.data.x - s.x, t.data.z - s.z) > 1.3) continue;
        // Check priority and shield
        if (owner.data.id === t.data.id) continue;
        if (owner.data.team === t.data.team) continue;
        if (owner.data.seq <= t.data.seq) continue;
        if ((t.data.shieldUntil || 0) > now && (t.data.shieldCharges || 0) > 0) {
          t.data.shieldCharges = 0; t.data.shieldUntil = 0;
          this.toast(t.data.nick + ' nasalag ang bato! 🛡️');
          t.avatar.pop?.();
          this._pStones = this._pStones.filter(x => x !== s);
          break;
        }
        t.data.state = 'captured'; t.data.capturedAt = Date.now();
        const line = [...this.players.values()].filter(e => e.data.team === t.data.team && e.data.state === 'captured');
        const idx = Math.max(0, line.length - 1);
        t.data.x = 4.5 + idx * 1.6;
        t.data.z = (owner.data.team === 'red' ? 22 : -22) - 1.5;
        t.data.wasInBase = false;
        t.avatar.setCaptured(true);
        owner.avatar.pop?.();
        if (owner.data.id === 'me') { this.toast('Nahuli mo si ' + t.data.nick + '!'); }
        if (t.data.id === 'me') this.toast('Nahuli ka ni ' + owner.data.nick + '!');
        owner.data.skill = null; owner.data.skillCount = 0;
        this._pStones = this._pStones.filter(x => x !== s);
        break;
      }
    }
    // Bomb update
    for (const b of [...this._pBombs]) {
      if (now < b.explodeAt) continue;
      this._pBombs = this._pBombs.filter(x => x !== b);
      this.boomFx(b.x, b.z);
      const victims = [...this.players.values()].filter(p =>
        p.data.team !== b.team && p.data.state === 'free' &&
        Math.hypot(p.data.x - b.x, p.data.z - b.z) <= 4);
      for (const v of victims) {
        v.data.stunUntil = now + 2500;
        if (v.data.id === 'me') this.toast('Na-stun ka! Takbo pag gising! 💣');
      }
      this.beep(180);
    }
    const bots = [...this.players.values()].filter(e => e.data.id !== 'me');
    for (const b of bots) {
      if (b.data.state !== 'free') continue;
      this.trackDepartureLocal(b);
      b.think = b.think || 0;
      if (nowT - b.think > 0.6) { b.think = nowT; b.wp = this.pPick(b); }
      if (b.wp) {
        const dx = b.wp.x - b.data.x, dz = b.wp.z - b.data.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.5) {
          b.data.x += (dx / d) * 6.5 * dt; b.data.z += (dz / d) * 6.5 * dt;
          b.data.rot = Math.atan2(dx, dz);
          this.trackDepartureLocal(b);
        }
      }
      b.tx = b.data.x; b.tz = b.data.z;
    }
    this.pTags();
    if (this.pElim()) return;
    this.pBotRescue();
    this.pCaps();
    const tail = this.pTail('red');
    const near = tail && me.data.state === 'free' &&
      Math.hypot(tail.data.x - me.data.x, tail.data.z - me.data.z) < 6;
    document.getElementById('rescue-banner').classList.toggle('hidden', !near);
    for (const e of this.players.values()) {
      if (e.data.state !== 'free' || !e.data.seq) { e.avatar.setCanTag(false); continue; }
      let hunter = false;
      for (const o of this.players.values()) {
        if (o.data.team === e.data.team || o.data.state !== 'free' || !o.data.seq) continue;
        if (e.data.seq > o.data.seq) { hunter = true; break; }
      }
      e.avatar.setCanTag(hunter);
      e.avatar.setJump(e.data.jumping, e.data.jumpProgress || 0);
    }
    this.updateHUD();
  }
  pPick(b) {
    const d = b.data;
    const foes = [...this.players.values()].filter(e =>
      e.data.team !== d.team && e.data.state === 'free' && e.data.seq);
    const tail = this.pTail(d.team);
    if (tail && !this.inBaseLocal(tail.data.x, tail.data.z, d.team))
      return { x: tail.data.x, z: tail.data.z };
    let prey = null;
    for (const f of foes) {
      if (d.seq > f.data.seq && (!prey || f.data.seq < prey.data.seq)) prey = f;
    }
    if (prey) return { x: prey.data.x + (Math.random() * 2 - 1), z: prey.data.z + (Math.random() * 2 - 1) };
    const hunters = foes.filter(f => f.data.seq > d.seq);
    if (hunters.length && d.seq) {
      const bz = d.team === 'red' ? 22 : -22;
      return { x: Math.random() * 6 - 3, z: bz + (d.team === 'red' ? -3 : 3) };
    }
    if (!d.seq) return { x: Math.random() * 10 - 5, z: Math.random() * 16 - 8 };
    const ebz = d.team === 'red' ? -22 : 22;
    if (Math.random() < 0.35) return { x: Math.random() * 6 - 3, z: ebz };
    return { x: Math.random() * 16 - 8, z: Math.random() * 20 - 10 };
  }
  pTags() {
    const free = [...this.players.values()].filter(e => e.data.state === 'free' && e.data.seq);
    const now = Date.now();
    for (const a of free) {
      for (const t of free) {
        if (a.data.team === t.data.team || a.data.seq <= t.data.seq) continue;
        if (Math.hypot(a.data.x - t.data.x, a.data.z - t.data.z) > 2.2) continue;
        // Check ghost and shield
        if ((t.data.ghostUntil || 0) > now) continue;
        if ((t.data.shieldUntil || 0) > now && (t.data.shieldCharges || 0) > 0) {
          t.data.shieldCharges = 0; t.data.shieldUntil = 0;
          this.toast(t.data.nick + ' nasalag! 🛡️');
          t.avatar.pop?.();
          break;
        }
        t.data.state = 'captured'; t.data.capturedAt = Date.now();
        t.avatar.setCaptured(true);
        const line = [...this.players.values()].filter(e =>
          e.data.team === t.data.team && e.data.state === 'captured');
        const idx = Math.max(0, line.length - 1);
        t.data.x = 4.5 + idx * 1.6;
        t.data.z = (a.data.team === 'red' ? 22 : -22) - 1.5;
        t.data.wasInBase = false;
        t.tx = t.data.x; t.tz = t.data.z;
        t.avatar.pop?.(); a.avatar.pop?.();
        if (a.data.id === 'me') { this.toast('Nahuli mo si ' + t.data.nick + '!'); this.beep(660); }
        if (t.data.id === 'me') this.toast('Nahuli ka ni ' + a.data.nick + '! Ikaw nauna kaya ikaw ang taya!');
        this.updateHUD();
        break;
      }
    }
  }
  pElim() {
    const all = [...this.players.values()].map(e => ({ team: e.data.team, state: e.data.state }));
    const reds = all.filter(p => p.team === 'red');
    const blues = all.filter(p => p.team === 'blue');
    if (!reds.length || !blues.length) return false;
    const redWiped = reds.every(p => p.state === 'captured');
    const blueWiped = blues.every(p => p.state === 'captured');
    if (!redWiped && !blueWiped) return false;
    this._pOver = true;
    if (redWiped && blueWiped) this.toast('Parehong team naubos — DRAW! Bawi!');
    else if (blueWiped) {
      this._pScore.red += 1; this.scores = this._pScore;
      this.toast('NAUBOS ANG BLUE — lahat nahuli! PANALO RED! 🏆 (' + this._pScore.red + '-' + this._pScore.blue + ')');
      this.beep(880);
    } else {
      this._pScore.blue += 1; this.scores = this._pScore;
      for (const e of this.players.values()) e.avatar.celebrate?.(e.data.team === 'blue');
      this.toast('NAUBOS ANG RED — lahat nahuli! Panalo Blue. Bawi next game!');
    }
    this.updateHUD();
    const nick = this.players.get('me')?.data.nick || 'Kabayan';
    clearTimeout(this._pRematch);
    this._pRematch = setTimeout(() => this.startPractice(nick), 5000);
    this.toast('Balik base lahat — bagong laro in 5s!');
    return true;
  }
  pBotRescue() {
    for (const b of this.players.values()) {
      if (b.data.id === 'me' || b.data.state !== 'free' || !b.data.seq) continue;
      const tail = this.pTail(b.data.team);
      if (!tail) continue;
      if (Math.hypot(tail.data.x - b.data.x, tail.data.z - b.data.z) < 1.6) {
        const freed = this.pFreeCaptured(b);
        freed.forEach(f => f.avatar.clearMood());
        b.avatar.hop?.();
        if (b.data.team === 'red') this.toast('Sagipin ang tropa! ' + b.data.nick + ' rescued +' + freed.length);
      }
    }
  }
  pCaps() {
    for (const b of this.players.values()) {
      if (b.data.state !== 'free' || !b.data.seq) continue;
      const foeBase = b.data.team === 'red' ? 'blue' : 'red';
      if (!this.inBaseLocal(b.data.x, b.data.z, foeBase)) continue;
      const defended = [...this.players.values()].some(e =>
        e.data.team === foeBase && e.data.state === 'free' &&
        this.inBaseLocal(e.data.x, e.data.z, foeBase));
      if (defended) continue;
      if (this._pOver) break;
      this._pScore[b.data.team] += 1;
      this.scores = this._pScore;
      this.toast('Lupit! ' + b.data.nick + ' nakalusot! ' + this._pScore.red + '-' + this._pScore.blue);
      this.beep(880);
      const bz = b.data.team === 'red' ? 22 : -22;
      b.data.x = 0; b.data.z = bz; b.data.seq = 0; b.data.wasInBase = true;
      b.tx = 0; b.tz = bz;
      this.updateHUD();
      if (this._pScore[b.data.team] >= 5) {
        this._pOver = true;
        for (const e of this.players.values()) e.avatar.celebrate?.(e.data.team === b.data.team);
        this.toast(b.data.team === 'red' ? 'PANALO RED! Balik base lahat — bagong laro in 5s!' : 'Panalo Blue. Bawi! Bagong laro in 5s!');
        const nick = this.players.get('me')?.data.nick || 'Kabayan';
        clearTimeout(this._pRematch);
        this._pRematch = setTimeout(() => this.startPractice(nick), 5000);
      }
    }
  }
  syncRunes(runes) {
    const icons = { swift: '⚡', dash: '💨', stone: '🪨', bomb: '💣', shield: '🛡️', ghost: '👻' };
    const colors = { swift: 0xFFFF00, dash: 0x00FFFF, stone: 0x888888, bomb: 0xFF4444, shield: 0x00FF00, ghost: 0x8888FF };
    for (const r of runes) {
      if (!this.runeMeshes.has(r.id)) {
        const g = new THREE.Group();
        const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 8),
          new THREE.MeshBasicMaterial({ color: colors[r.type] || 0xFFFFFF }));
        g.add(sphere);
        const text = makeRuneText(icons[r.type] || '?');
        text.position.y = 0.8;
        g.add(text);
        g.position.set(r.x, 0.5, r.z);
        this.scene.add(g);
        this.runeMeshes.set(r.id, g);
      }
    }
    for (const [id, mesh] of this.runeMeshes) {
      if (!runes.find(r => r.id === id)) {
        this.scene.remove(mesh);
        this.runeMeshes.delete(id);
      }
    }
  }
  boomFx(x, z) {
    const boom = new THREE.Mesh(new THREE.SphereGeometry(4, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xFF6600, transparent: true, opacity: 0.6 }));
    boom.position.set(x, 1, z);
    this.scene.add(boom);
    const startTime = performance.now();
    const anim = () => {
      const elapsed = (performance.now() - startTime) / 1000;
      if (elapsed > 0.5) { this.scene.remove(boom); return; }
      boom.scale.setScalar(1 + elapsed * 2);
      boom.material.opacity = 0.6 * (1 - elapsed * 2);
      requestAnimationFrame(anim);
    };
    anim();
  }
  updateSkillHUD() {
    const tray = document.getElementById('rune-tray');
    const skillBtn = document.getElementById('btn-skill');
    const me = this.players.get(this.meId);

    if (!me) {
      tray.classList.add('hidden');
      skillBtn.textContent = '✨ SKILL (F)';
      skillBtn.classList.remove('ready');
      skillBtn.dataset.skill = 'none';
      return;
    }

    const character = me.data.species || 'naruto';
    const skills = getCharacterSkills(character);

    // Clear existing skill buttons in tray
    tray.innerHTML = '';
    tray.classList.remove('hidden');

    // Create skill buttons for each character skill
    skills.skills.forEach((skill, index) => {
      const btn = document.createElement('button');
      btn.className = 'skill-icon';
      btn.innerHTML = `${skill.icon}<span class="skill-key">${index + 1}</span>`;
      btn.title = `${skill.name}: ${skill.description}`;
      btn.dataset.skillId = skill.id;
      btn.dataset.character = character;
      btn.style.borderColor = '#' + skill.color.toString(16).padStart(6, '0');
      tray.appendChild(btn);
    });

    // Update main skill button
    skillBtn.textContent = '✨ SKILLS (1-4)';
    skillBtn.dataset.skill = character;
    skillBtn.classList.add('ready');
  }
}
function makeRuneText(char) {
  const cv = document.createElement('canvas'); cv.width = 64; cv.height = 64;
  const cx = cv.getContext('2d');
  cx.fillStyle = '#000000'; cx.fillRect(0, 0, 64, 64);
  cx.fillStyle = '#FFFFFF'; cx.font = 'bold 48px Arial';
  cx.textAlign = 'center'; cx.textBaseline = 'middle';
  cx.fillText(char, 32, 32);
  const tx = new THREE.CanvasTexture(cv);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx }));
  sp.scale.set(1.5, 1.5, 1);
  return sp;
}
function fmtTime(s) { s = Math.max(0, s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
