// Socket.IO client wrapper with offline/practice fallback.
import { io } from 'socket.io-client';
const URL = (typeof __SERVER_URL__ !== 'undefined' && __SERVER_URL__) || 'http://localhost:3000';
export class Net {
  constructor() {
    this.connected = false; this.handlers = {};
    this.id = null; this.offline = false;
    try {
      this.socket = io(URL, { transports: ['websocket', 'polling'], timeout: 4000 });
      this.socket.on('connect', () => {
        this.connected = true; this.id = this.socket.id;
        this.emit2('status', { connected: true });
      });
      this.socket.on('disconnect', () => {
        this.connected = false; this.emit2('status', { connected: false });
      });
      this.socket.on('connect_error', () => {
        this.emit2('status', { connected: false });
      });
      ['room:state', 'match:start', 'match:rematch', 'match:tick', 'match:end', 'player:tagged',
       'player:rescued', 'player:dashed', 'base:captured', 'rescue:prompt', 'error:msg', 'chat:msg',
       'rune:spawned', 'rune:taken', 'rune:got', 'stone:thrown', 'bomb:thrown', 'bomb:boom', 'shield:blocked'
      ].forEach(ev => this.socket.on(ev, (d) => this.emit2(ev, d)));
    } catch { this.connected = false; }
  }
  on(ev, fn) { (this.handlers[ev] ||= []).push(fn); }
  emit2(ev, d) { (this.handlers[ev] || []).forEach(f => { try { f(d); } catch {} }); }
  send(ev, d) { if (this.connected && this.socket) this.socket.emit(ev, d); }
}
