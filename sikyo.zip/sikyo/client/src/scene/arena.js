// Low-poly Pinoy neighborhood arena. Fair + readable, decor off-play.
import * as THREE from 'three';
export function buildArena(scene) {
  const H = 28, out = { flags: [] };
  scene.background = new THREE.Color(0x87ceeb);
  scene.fog = new THREE.Fog(0x87ceeb, 60, 140);
  const sun = new THREE.DirectionalLight(0xfff5e1, 1.8);
  sun.position.set(20, 35, 10);
  sun.castShadow = true;
  sun.shadow.mapSize.width = 2048;
  sun.shadow.mapSize.height = 2048;
  sun.shadow.camera.near = 0.5;
  sun.shadow.camera.far = 100;
  sun.shadow.camera.left = -40;
  sun.shadow.camera.right = 40;
  sun.shadow.camera.top = 40;
  sun.shadow.camera.bottom = -40;
  scene.add(sun);
  scene.add(new THREE.HemisphereLight(0xbfe3ff, 0x3a7d44, 0.95));
  const ambient = new THREE.AmbientLight(0xffffff, 0.4);
  scene.add(ambient);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(H * 2 + 16, H * 2 + 16),
    new THREE.MeshLambertMaterial({ color: 0x9fd18b }));
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  const court = new THREE.Mesh(new THREE.PlaneGeometry(H * 2, H * 2),
    new THREE.MeshLambertMaterial({ color: 0xE8E0C8 }));
  court.rotation.x = -Math.PI / 2; court.position.y = 0.02;
  court.receiveShadow = true;
  scene.add(court);
  const line = (w, l, x, z, c = 0xffffff) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, l),
      new THREE.MeshBasicMaterial({ color: c }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, 0.04, z); scene.add(m);
  };
  line(H * 2, 0.4, 0, 0); line(0.4, H * 2, 0, 0);
  line(H * 2, 0.3, 0, -H); line(H * 2, 0.3, 0, H);
  const mkBase = (team, z, color) => {
    const g = new THREE.Group();
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(5, 5, 0.3, 24),
      new THREE.MeshLambertMaterial({ color }));
    disc.position.y = 0.15; g.add(disc);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(5, 0.25, 8, 32),
      new THREE.MeshBasicMaterial({ color: 0xFFD23F }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.4; g.add(ring);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 6),
      new THREE.MeshLambertMaterial({ color: 0x8b5a2b }));
    pole.position.y = 3; g.add(pole);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.4),
      new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide }));
    flag.position.set(1.3, 5, 0); g.add(flag); out.flags.push(flag);
    const label = makeText(team === 'red' ? 'RED BASE' : 'BLUE BASE');
    label.position.y = 7; g.add(label);
    g.position.set(0, 0, z); scene.add(g);
  };
  mkBase('red', 22, 0xE63946); mkBase('blue', -22, 0x36A9E1);
  // walls + gates
  const wallMat = new THREE.MeshLambertMaterial({ color: 0xd9d2bd });
  [[0, H + 2, H * 2 + 12, 1], [0, -H - 2, H * 2 + 12, 1]].forEach(([x, z, w]) => {
    const wmesh = new THREE.Mesh(new THREE.BoxGeometry(w, 2.5, 1),
      wallMat); wmesh.position.set(x, 1.25, z); scene.add(wmesh);
  });
  // houses (outside play)
  const houseCols = [0xFFD23F, 0x24A66A, 0xFF8FA3, 0x36A9E1];
  for (let i = 0; i < 8; i++) {
    const c = houseCols[i % 4];
    const hx = (i % 2 ? 1 : -1) * (H + 8);
    const hz = -H + i * 8;
    const h = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(5, 3, 4),
      new THREE.MeshLambertMaterial({ color: c }));
    body.position.y = 1.5; body.castShadow = true; body.receiveShadow = true; h.add(body);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(4, 2, 4),
      new THREE.MeshLambertMaterial({ color: 0x8b3a2b }));
    roof.position.y = 4; roof.rotation.y = Math.PI / 4; roof.castShadow = true; h.add(roof);
    // Windows
    const windowGeom = new THREE.BoxGeometry(0.8, 0.8, 0.1);
    const windowMat = new THREE.MeshBasicMaterial({ color: 0x87CEEB });
    [[-1.2, 2.2, 2.05], [1.2, 2.2, 2.05]].forEach(([x, y, z]) => {
      const win = new THREE.Mesh(windowGeom, windowMat);
      win.position.set(x, y, z);
      h.add(win);
    });
    h.position.set(hx, 0, hz); scene.add(h);
  }
  // sari-sari store
  const store = new THREE.Group();
  const sbody = new THREE.Mesh(new THREE.BoxGeometry(6, 3, 4),
    new THREE.MeshLambertMaterial({ color: 0xE63946 }));
  sbody.position.y = 1.5; sbody.castShadow = true; store.add(sbody);
  const sign = makeText('SARI-SARI'); sign.position.y = 4; store.add(sign);
  // Add awning
  const awning = new THREE.Mesh(new THREE.BoxGeometry(7, 0.2, 5),
    new THREE.MeshLambertMaterial({ color: 0xFFD23F }));
  awning.position.set(0, 3.1, 0.5); awning.castShadow = true; store.add(awning);
  store.position.set(H + 9, 0, 0); store.rotation.y = -Math.PI / 2; scene.add(store);

  // Jeepney (iconic Filipino vehicle)
  const jeepney = createJeepney();
  jeepney.position.set(-H - 8, 0, 0);
  jeepney.rotation.y = Math.PI / 4;
  scene.add(jeepney);

  // Bamboo decor (traditional Filipino material)
  const bambooGroup = new THREE.Group();
  for (let i = 0; i < 6; i++) {
    const bamboo = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 8),
      new THREE.MeshLambertMaterial({ color: 0x8B7355 }));
    bamboo.position.set((i - 2.5) * 0.8, 4, H + 6);
    bamboo.castShadow = true;
    bambooGroup.add(bamboo);
  }
  scene.add(bambooGroup);

  // More vibrant fiesta banners with triangle patterns
  for (let i = -3; i <= 3; i++) {
    const b = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.8),
      new THREE.MeshBasicMaterial({ color: i % 2 ? 0xFFD23F : 0xE63946, side: THREE.DoubleSide }));
    b.position.set(i * 7, 9, 0);
    scene.add(b);
    // Add triangular buntings
    for (let j = 0; j < 3; j++) {
      const triGeom = new THREE.ConeGeometry(0.3, 0.6, 3);
      const triMat = new THREE.MeshBasicMaterial({ color: j % 2 ? 0x24A66A : 0xFF8FA3 });
      const tri = new THREE.Mesh(triGeom, triMat);
      tri.position.set(i * 7 + (j - 1) * 0.8, 8, 0);
      tri.rotation.z = Math.PI;
      scene.add(tri);
    }
  }
  // trees with animated leaves
  for (let i = 0; i < 10; i++) {
    const t = new THREE.Group();
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 2),
      new THREE.MeshLambertMaterial({ color: 0x7a4a21 }));
    trunk.position.y = 1; trunk.castShadow = true; t.add(trunk);
    const top = new THREE.Mesh(new THREE.IcosahedronGeometry(1.6, 0),
      new THREE.MeshLambertMaterial({ color: 0x24A66A }));
    top.position.y = 3; top.castShadow = true; t.add(top);
    const a = (i / 10) * Math.PI * 2;
    t.position.set(Math.cos(a) * (H + 5), 0, Math.sin(a) * (H + 5));
    t.userData = { treeIndex: i };
    scene.add(t);
    out.trees = out.trees || [];
    out.trees.push(t);
  }
  // fiesta banners across
  for (let i = -2; i <= 2; i++) {
    const b = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.8),
      new THREE.MeshBasicMaterial({ color: i % 2 ? 0xFFD23F : 0xE63946, side: THREE.DoubleSide }));
    b.position.set(i * 8, 8, 0); scene.add(b);
  }
  // basketball hoop decor (side, non-blocking)
  const hoop = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 4),
    new THREE.MeshLambertMaterial({ color: 0x333333 }));
  post.position.y = 2; hoop.add(post);
  hoop.position.set(-H - 4, 0, 0); scene.add(hoop);
  out.update = (t) => {
    out.flags.forEach((f, i) => { f.position.y = 5 + Math.sin(t * 2 + i) * 0.15; });
    // Animate trees slightly
    if (out.trees) {
      out.trees.forEach((tree, i) => {
        tree.rotation.y = Math.sin(t * 0.5 + i) * 0.05;
      });
    }
  };
  return out;
}
function createJeepney() {
  const jeep = new THREE.Group();
  // Body
  const body = new THREE.Mesh(new THREE.BoxGeometry(4, 2, 2.5),
    new THREE.MeshLambertMaterial({ color: 0xFFD700 }));
  body.position.y = 1.5; body.castShadow = true; jeep.add(body);
  // Roof
  const roof = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.3, 2.7),
    new THREE.MeshLambertMaterial({ color: 0x8B0000 }));
  roof.position.y = 2.6; roof.castShadow = true; jeep.add(roof);
  // Wheels
  const wheelGeom = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 16);
  const wheelMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
  [[-1.2, 0.4], [1.2, 0.4], [-1.2, -0.4], [1.2, -0.4]].forEach(([x, z]) => {
    const wheel = new THREE.Mesh(wheelGeom, wheelMat);
    wheel.rotation.x = Math.PI / 2;
    wheel.position.set(x, 0.4, z);
    wheel.castShadow = true;
    jeep.add(wheel);
  });
  // Decorative stripes
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.3, 0.2, 2.6),
    new THREE.MeshLambertMaterial({ color: 0xFFFFFF }));
  stripe.position.y = 1.8; jeep.add(stripe);
  return jeep;
}
function makeText(str) {
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
  const cx = cv.getContext('2d');
  cx.fillStyle = '#151923'; cx.fillRect(0, 0, 256, 64);
  cx.fillStyle = '#FFD23F'; cx.font = 'bold 32px Poppins,sans-serif';
  cx.textAlign = 'center'; cx.fillText(str, 128, 44);
  const tx = new THREE.CanvasTexture(cv);
  return new THREE.Mesh(new THREE.PlaneGeometry(5, 1.25),
    new THREE.MeshBasicMaterial({ map: tx, transparent: false }));
}
