// Anime character avatars (Naruto/Goku/Saitama/Gojo/Killua) from Three.js
// primitives — stylized chibi versions with iconic features, team scarf, name tag, priority ring.
import * as THREE from 'three';
export const SPECIES = ['naruto', 'goku', 'saitama', 'gojo', 'killua'];
export const SPECIES_EMOJI = { naruto: 'NR', goku: 'GK', saitama: 'ST', gojo: 'GJ', killua: 'KL' };
const SKIN = 0xFFE4C4, PINK = 0xFF9FB2, DARK = 0x2B2320;
const lam = (c) => new THREE.MeshPhongMaterial({ color: c });
const TEAMC = (t) => (t === 'red' ? 0xE63946 : 0x36A9E1);
export function createAvatar(team, nick, species = 'naruto') {
  if (!SPECIES.includes(species)) species = 'naruto';
  const g = new THREE.Group();
  const skin = lam(SKIN);
  const teamC = TEAMC(team);
  const wiggle = [];
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.55, 14, 12), skin);
  body.scale.set(1, 1.1, 0.9); body.position.y = 0.75; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.62, 16, 14), skin);
  head.position.y = 1.7; g.add(head);
  const pupils = [];
  [-1, 1].forEach((s) => {
    const white = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), lam(0xffffff));
    white.position.set(0.22 * s, 1.84, 0.5); g.add(white);
    const pup = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), lam(DARK));
    pup.position.set(0.22 * s, 1.84, 0.6); g.add(pup); pupils.push(pup);
    const glint = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0xffffff }));
    glint.position.set(0.19 * s, 1.88, 0.66); g.add(glint);
  });
  buildCharacterFeatures(species, g, skin, wiggle);
  buildCharacterHair(species, g, wiggle);
  const nub = (r, mat, x, y) => {
    const pivot = new THREE.Group(); pivot.position.set(x, y, 0);
    const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), mat);
    m.position.y = -r * 0.9; pivot.add(m); g.add(pivot); return pivot;
  };
  const armL = nub(0.16, fur, -0.55, 1.0);
  const armR = nub(0.16, fur, 0.55, 1.0);
  const legL = nub(0.19, fur, -0.24, 0.42);
  const legR = nub(0.19, fur, 0.24, 0.42);
  const scarfMat = lam(teamC);
  const scarf = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.11, 8, 20), scarfMat);
  scarf.rotation.x = Math.PI / 2; scarf.position.y = 1.12; g.add(scarf);
  const knot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.24, 0.1), scarfMat);
  knot.position.set(0.28, 1.0, 0.36); knot.rotation.z = 0.3; g.add(knot);
  // Add team-colored bandana decoration
  const bandanaDecor = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.02, 8, 20),
    new THREE.MeshBasicMaterial({ color: 0xFFD23F }));
  bandanaDecor.rotation.x = Math.PI / 2; bandanaDecor.position.y = 1.12; g.add(bandanaDecor);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.08, 8, 24),
    new THREE.MeshBasicMaterial({ color: 0xFFD23F }));
  ring.rotation.x = Math.PI / 2; ring.position.y = 0.1; g.add(ring);
  const shieldBubble = new THREE.Mesh(new THREE.SphereGeometry(1.15, 14, 12),
    new THREE.MeshBasicMaterial({ color: 0x36A9E1, transparent: true, opacity: 0.25 }));
  shieldBubble.position.y = 1.1; shieldBubble.visible = false; g.add(shieldBubble);
  g.add(makeTag(nick, team));
  const api = { group: g, species, _pop: 0, _hop: 0, _dance: 0,
    _px: 0, _pz: 0, _vx: 0, _vz: 0, _tilt: 0, _dashFx: 0, _skillFx: 0,
    _stun: false, _ghost: false, _shield: false, _swift: false,
    _jumping: false, _jumpProgress: 0, _skillType: null, _origSkinColor: skin.color.getHex(),
    _wasJumping: false, _dustFx: 0, _spawnedDust: false, _skillParticleSpawned: false,
    setCaptured(c) {
      g.rotation.z = c ? 0.3 : (this._dance === -1 ? -0.15 : 0);
      pupils.forEach((p) => { p.scale.y = c ? 0.15 : 1; });
      const m = lam(c ? 0x8a8a8a : teamC);
      scarf.material = m; knot.material = m;
    },
    setCanTag(v) { ring.visible = v; },
    setFx(fx) {
      fx = fx || {};
      this._stun = !!fx.stun; this._ghost = !!fx.ghost;
      this._shield = !!fx.shield; this._swift = !!fx.swift;
      skin.transparent = this._ghost;
      skin.opacity = this._ghost ? 0.4 : 1;
      shieldBubble.visible = this._shield;
    },
    setJump(jumping, progress) {
      this._jumping = jumping;
      this._jumpProgress = progress || 0;
      // Trigger dust effect on landing
      if (this._wasJumping && !jumping) {
        this._dustFx = 1;
      }
      this._wasJumping = jumping;
    },
    pop() { this._pop = 1; },
    hop() { this._hop = 1; },
    dash() { this._dashFx = 1; },
    skillCast(type) {
      this._skillFx = 1; this._pop = 0.7; this._skillType = type;
      this._skillCastTime = Date.now();
    },
    celebrate(win) { this._dance = win ? 1 : -1; if (!win) g.rotation.z = -0.15; },
    clearMood() { this._dance = 0; this._pop = 0; this._hop = 0; this._dashFx = 0; this._skillFx = 0; this._skillType = null; fur.color.setHex(this._origFurColor); g.rotation.z = 0; g.rotation.y = 0; },
    anim(t, dt, moving, sprint, faceRot) {
      dt = Math.min(dt || 0.016, 0.05);
      const wx = g.position.x, wz = g.position.z;
      const ivx = (wx - this._px) / Math.max(dt, 0.001), ivz = (wz - this._pz) / Math.max(dt, 0.001);
      this._px = wx; this._pz = wz;
      this._vx += (ivx - this._vx) * 0.25; this._vz += (ivz - this._vz) * 0.25;
      const spd = Math.hypot(this._vx, this._vz);
      let target = (faceRot !== undefined && faceRot !== null) ? faceRot : g.rotation.y;
      if (spd > 1) target = Math.atan2(this._vx, this._vz);
      let d = target - g.rotation.y;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      g.rotation.y += d * Math.min(1, dt * 12);
      const lean = Math.max(-0.3, Math.min(0.3, spd * 0.025));
      this._tilt += (lean - this._tilt) * 0.2;
      g.rotation.x = this._dance === 1 ? 0 : this._tilt;
      if (this._dashFx > 0) this._dashFx = Math.max(0, this._dashFx - dt * 3);
      if (this._skillFx > 0) this._skillFx = Math.max(0, this._skillFx - dt * 2.2);
      if (this._dance === 1) {
        g.rotation.y += dt * 5;
        g.position.y = Math.abs(Math.sin(t * 8)) * 0.35;
      } else {
        const cyc = moving ? ((sprint || this._swift) ? 11 : 8) : 2.2;
        const amp = moving ? Math.min(0.9, 0.45 + spd * 0.04) : 0.07;
        legL.rotation.x = Math.sin(t * cyc) * amp;
        legR.rotation.x = -Math.sin(t * cyc) * amp;
        armL.rotation.x = -Math.sin(t * cyc) * amp;
        armR.rotation.x = Math.sin(t * cyc) * amp;
        const bob = Math.abs(Math.sin(t * cyc)) * (moving ? (sprint ? 0.12 : 0.08) : 0.03);
        let jumpHeight = 0;
        if (this._jumping) {
          const progress = this._jumpProgress;
          jumpHeight = Math.sin(progress * Math.PI) * 2.5;
          // Tuck animation during jump
          body.scale.y = 1.1 - Math.sin(progress * Math.PI) * 0.2;
          head.position.y = 1.7 - Math.sin(progress * Math.PI) * 0.15;
          // Arms up during jump
          armL.rotation.x = -Math.PI / 3 + Math.sin(progress * Math.PI) * 0.5;
          armR.rotation.x = -Math.PI / 3 + Math.sin(progress * Math.PI) * 0.5;
        } else {
          head.position.y = 1.7 + Math.sin(t * 2.5) * 0.04;
          body.scale.y = 1.1 - Math.sin(t * cyc * 2) * (moving ? 0.05 : 0.015);
        }
        g.position.y = bob + (this._hop > 0 ? Math.sin((1 - this._hop) * Math.PI) * 0.55 : 0) + jumpHeight;
        if (this._hop > 0) this._hop = Math.max(0, this._hop - dt * 2.5);
      }
      if (this._pop > 0) this._pop = Math.max(0, this._pop - dt * 3);
      let s = 1 + this._pop * 0.28 + this._dashFx * 0.12;
      if (this._skillFx > 0) {
        s += Math.sin((1 - this._skillFx) * Math.PI) * 0.18;
        // Skill-specific effects using emissive instead of color
        if (this._skillType === 'swift') {
          skin.emissive = new THREE.Color(0xFFFF00);
          skin.emissiveIntensity = Math.sin((1 - this._skillFx) * Math.PI) * 0.8;
        } else if (this._skillType === 'ghost') {
          skin.emissive = new THREE.Color(0x8888FF);
          skin.emissiveIntensity = Math.sin((1 - this._skillFx) * Math.PI) * 0.5;
        } else if (this._skillType === 'shield') {
          shieldBubble.material.color.setHex(0x00FF00);
        } else {
          skin.emissiveIntensity = 0;
        }
      } else {
        skin.emissiveIntensity = 0;
        if (this._shield) shieldBubble.material.color.setHex(0x36A9E1);
      }
      if (this._stun) {
        g.position.x += Math.sin(t * 40) * 0.03;
        g.position.z += Math.cos(t * 40) * 0.03;
        g.rotation.z = Math.sin(t * 20) * 0.2;
        pupils.forEach((p) => { p.scale.x = 0.15; p.scale.y = 0.15; });
        // Spiral effect
        fur.emissive = new THREE.Color(0xFF0000);
        fur.emissiveIntensity = Math.sin(t * 10) * 0.3 + 0.3;
      } else {
        pupils.forEach((p) => { p.scale.x = 1; p.scale.y = 1; });
        fur.emissiveIntensity = 0;
      }
      // Dust effect on landing
      if (this._dustFx > 0) {
        this._dustFx = Math.max(0, this._dustFx - dt * 3);
        const dustScale = (1 - this._dustFx) * 0.8;
        // Visual feedback for dust (could add particles here)
      }
      const sy = 2 - s > 0.4 ? (2 - s) : 1;
      g.scale.set(s, this._dashFx > 0 ? sy * 0.9 : sy, s);
      if (this._shield) shieldBubble.scale.setScalar(1 + Math.sin(t * 5) * 0.06);
      wiggle.forEach((e, i) => { e.rotation.z = (i ? -1 : 1) * (0.1 + Math.sin(t * 4 + i) * (0.08 + spd * 0.008)); });
    }
  };
  return api;
}
function buildCharacterFeatures(species, g, skin, wiggle) {
  if (species === 'naruto') {
    // Naruto's whisker marks
    [-1, 1].forEach((s) => {
      for (let i = 0; i < 3; i++) {
        const whisker = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.02, 0.02),
          new THREE.MeshBasicMaterial({ color: 0x2B2320 }));
        whisker.position.set(0.35 * s, 1.55 + i * 0.08, 0.62);
        g.add(whisker);
      }
    });
  } else if (species === 'goku') {
    // Goku's spiky hair line
    const hairline = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 0.15),
      new THREE.MeshLambertMaterial({ color: 0x000000 }));
    hairline.position.set(0, 2.15, 0.3);
    g.add(hairline);
  } else if (species === 'saitama') {
    // Saitama's bald head (already skin color)
    const shine = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3 }));
    shine.position.set(0, 2.0, 0.4);
    g.add(shine);
  } else if (species === 'gojo') {
    // Gojo's white hair base
    const hairBase = new THREE.Mesh(new THREE.SphereGeometry(0.65, 16, 14),
      new THREE.MeshLambertMaterial({ color: 0xFFFFFF }));
    hairBase.position.y = 1.85;
    hairBase.scale.set(1, 0.8, 0.9);
    g.add(hairBase);
  } else if (species === 'killua') {
    // Killua's spiky silver hair
    const hairBase = new THREE.Mesh(new THREE.SphereGeometry(0.65, 16, 14),
      new THREE.MeshLambertMaterial({ color: 0xC0C0C0 }));
    hairBase.position.y = 1.85;
    hairBase.scale.set(1, 0.8, 0.9);
    g.add(hairBase);
  }
}
function buildCharacterHair(species, g, wiggle) {
  if (species === 'naruto') {
    // Naruto's yellow spiky hair
    const spike = (x, y, z, rz) => {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.5, 4),
        new THREE.MeshLambertMaterial({ color: 0xFFD700 }));
      s.position.set(x, y, z);
      s.rotation.z = rz;
      s.rotation.x = 0.3;
      wiggle.push(s);
      g.add(s);
    };
    spike(0, 2.2, 0.1, 0);
    spike(-0.25, 2.1, 0.15, 0.3);
    spike(0.25, 2.1, 0.15, -0.3);
    spike(-0.15, 2.35, -0.1, 0.15);
    spike(0.15, 2.35, -0.1, -0.15);
  } else if (species === 'goku') {
    // Goku's black spiky hair
    const spike = (x, y, z, rz) => {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.6, 4),
        new THREE.MeshLambertMaterial({ color: 0x000000 }));
      s.position.set(x, y, z);
      s.rotation.z = rz;
      s.rotation.x = 0.2;
      wiggle.push(s);
      g.add(s);
    };
    spike(0, 2.3, 0.15, 0);
    spike(-0.2, 2.2, 0.2, 0.4);
    spike(0.2, 2.2, 0.2, -0.4);
    spike(-0.1, 2.5, -0.05, 0.2);
    spike(0.1, 2.5, -0.05, -0.2);
    spike(0, 2.7, 0, 0);
  } else if (species === 'saitama') {
    // Saitama's cape
    const cape = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.2, 0.1),
      new THREE.MeshLambertMaterial({ color: 0xFFFFFF }));
    cape.position.set(0, 1.0, -0.45);
    cape.rotation.x = 0.2;
    g.add(cape);
  } else if (species === 'gojo') {
    // Gojo's blindfold
    const blindfold = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.15, 0.1),
      new THREE.MeshLambertMaterial({ color: 0x000000 }));
    blindfold.position.set(0, 1.85, 0.55);
    g.add(blindfold);
  } else if (species === 'killua') {
    // Killua's spiky hair (more spikes)
    const spike = (x, y, z, rz) => {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.5, 4),
        new THREE.MeshLambertMaterial({ color: 0xC0C0C0 }));
      s.position.set(x, y, z);
      s.rotation.z = rz;
      s.rotation.x = 0.3;
      wiggle.push(s);
      g.add(s);
    };
    for (let i = -2; i <= 2; i++) {
      spike(i * 0.12, 2.1 + Math.abs(i) * 0.1, 0.15, i * 0.2);
    }
  }
}
//__EARS__
function makeTag(nick, team) {
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
  const cx = cv.getContext('2d');
  cx.fillStyle = team === 'red' ? '#E63946' : '#36A9E1';
  cx.fillRect(0, 0, 256, 64);
  cx.fillStyle = '#fff'; cx.font = 'bold 28px Poppins,sans-serif';
  cx.textAlign = 'center'; cx.fillText(String(nick || '?').slice(0, 12), 128, 42);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv) }));
  sp.scale.set(2.4, 0.6, 1); sp.position.y = 3.0; return sp;
}
