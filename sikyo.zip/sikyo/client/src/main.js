// Entry: screens, net wiring, game boot.
import { Net } from './network/socket.js';
import { Game } from './game/Game.js';
const $ = (id) => document.getElementById(id);
const net = new Net();
const game = new Game($('game-canvas'), net);
let myTeam = 'red';
function show(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  if (id) $(id).classList.add('active');
}
$('btn-play').onclick = () => show('screen-lobby');
$('btn-how').onclick = () => show('screen-how');
document.querySelectorAll('.back-btn').forEach(b => b.onclick = () => show(b.dataset.back));
$('btn-custom').onclick = () => game.toast('Customize: team colors + name — full closet soon!');
$('btn-board').onclick = () => game.toast('Leaderboard: online soon. Laro muna!');
$('btn-settings').onclick = () => game.toast('Settings: sound toggle in HUD 🔊');
$('team-red').onclick = () => { myTeam = 'red'; net.send('room:team', { team: 'red', species: species() }); flashTeam(); };
$('team-blue').onclick = () => { myTeam = 'blue'; net.send('room:team', { team: 'blue', species: species() }); flashTeam(); };
function flashTeam() { game.toast(myTeam === 'red' ? 'Team RED! 🔴' : 'Team BLUE! 🔵'); }
function nick() { return ($('nick').value || 'Kabayan').slice(0, 16); }
function species() { const v = ($('species')?.value || 'random'); return v === 'random' ? undefined : v; }
if ($('species')) $('species').onchange = (e) => game.previewSpecies(e.target.value === 'random' ? 'fox' : e.target.value);
$('btn-quick').onclick = () => net.send('room:quick', { nick: nick(), team: myTeam, species: species() });
$('btn-create').onclick = () => net.send('room:create', { nick: nick(), team: myTeam, species: species() });
$('btn-join').onclick = () => {
  const c = ($('room-code').value || '').toUpperCase().trim();
  if (c) net.send('room:join', { nick: nick(), team: myTeam, species: species(), roomCode: c });
  else game.toast('Lagay mo muna ang room code, kabayan!');
};
$('btn-ready').onclick = () => net.send('room:ready', { ready: true });
$('btn-practice').onclick = () => {
  show(null); game.setMe('me'); game.startPractice(nick());
  $('menu-status').textContent = 'Practice (offline)';
};
$('btn-rematch').onclick = () => { show(null); $('hud').classList.remove('hidden'); game.toast('Rematch — Laro na ulit!'); };
$('btn-to-lobby').onclick = () => { show('screen-lobby'); $('hud').classList.add('hidden'); };
net.on('status', (s) => {
  $('menu-status').textContent = s.connected ? 'Connected — Laro na, kabayan!' : 'Offline — practice mode available';
  $('lobby-status').textContent = s.connected ? 'Connected ✅' : 'Offline ❌ (practice only)';
});
net.on('room:state', (st) => {
  game.setMe();
  $('lobby-code').textContent = st.roomCode ? ('ROOM: ' + st.roomCode) : '';
  const reds = st.players.filter(p => p.team === 'red');
  const blues = st.players.filter(p => p.team === 'blue');
  $('list-red').innerHTML = reds.map(p => '<li>' + esc(p.nick) + (p.ready ? ' ✅' : '') + '</li>').join('');
  $('list-blue').innerHTML = blues.map(p => '<li>' + esc(p.nick) + (p.ready ? ' ✅' : '') + '</li>').join('');
  $('lobby-status').textContent = st.status.toUpperCase() + ' • ' + st.players.length + ' players';
});
net.on('match:start', (d) => {
  show(null); $('hud').classList.remove('hidden');
  game.setMe();
  if (d.go) { hideCount(); game.toast('LARO NA! Diskartehan mo!'); }
  else { showCount(d.countdown); game.beep(520); }
});
net.on('match:end', (d) => {
  $('hud').classList.add('hidden');
  $('res-title').textContent = d.winner === 'draw' ? 'DRAW!' : ('PANALO: TEAM ' + String(d.winner).toUpperCase() + '! 🏆');
  $('res-score').textContent = d.scores.red + ' - ' + d.scores.blue;
  $('res-stats').innerHTML = d.stats.map(s =>
    '<li>' + esc(s.nick) + ' — tags:' + s.tags + ' rescues:' + s.rescues + ' caps:' + s.captures + '</li>').join('');
  $('res-msg').textContent = (d.winner === 'draw' ? 'Bawi next game!' : 'Lupit mo, kabayan!') +
    ' Balik base lahat — bagong laro in ' + (d.rematchIn || 5) + 's…';
  show('screen-results');
  game.toast('Balik base lahat — bagong laro in ' + (d.rematchIn || 5) + 's!');
});
net.on('match:rematch', (d) => {
  show(null); $('hud').classList.remove('hidden');
  game.setMe();
  game.toast(d.text || 'Bagong laro! Balik base!');
  game.beep(700);
});
net.on('error:msg', (d) => game.toast(d.text));
net.on('rescue:prompt', () => {
  const b = $('rescue-banner'); b.classList.remove('hidden');
  clearTimeout(window._rb); window._rb = setTimeout(() => b.classList.add('hidden'), 3000);
});
function showCount(n) { const c = $('countdown'); c.textContent = n > 0 ? n : 'LARO!'; c.classList.remove('hidden'); if (n <= 0) setTimeout(hideCount, 800); }
function hideCount() { $('countdown').classList.add('hidden'); }
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
