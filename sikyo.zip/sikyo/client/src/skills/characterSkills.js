// Character-specific skills for anime characters
// Each character has 4 unique skills with cooldowns and effects

export const CHARACTER_SKILLS = {
  naruto: {
    name: 'Naruto',
    skills: [
      {
        id: 'rasengan',
        name: 'RASENGAN',
        icon: '🌀',
        color: 0x00BFFF,
        cooldown: 8,
        description: 'Spin attack - stuns nearby enemies',
        type: 'aoe',
        range: 3,
        damage: 0
      },
      {
        id: 'shadow_clone',
        name: 'SHADOW CLONE',
        icon: '👥',
        color: 0xFF6347,
        cooldown: 12,
        description: 'Create decoy - distracts enemies',
        type: 'decoy',
        range: 0,
        damage: 0
      },
      {
        id: 'rasen_shuriken',
        name: 'RASEN SHURIKEN',
        icon: '⭐',
        color: 0xFFD700,
        cooldown: 15,
        description: 'Ranged projectile - long range stun',
        type: 'projectile',
        range: 10,
        damage: 0
      },
      {
        id: 'sage_mode',
        name: 'SAGE MODE',
        icon: '🧘',
        color: 0x32CD32,
        cooldown: 20,
        description: 'Boost speed + immunity for 5s',
        type: 'buff',
        range: 0,
        damage: 0
      }
    ]
  },
  goku: {
    name: 'Goku',
    skills: [
      {
        id: 'kamehameha',
        name: 'KAMEHAMEHA',
        icon: '💥',
        color: 0x0066FF,
        cooldown: 10,
        description: 'Energy beam - long range knockback',
        type: 'beam',
        range: 15,
        damage: 0
      },
      {
        id: 'kaio_ken',
        name: 'KAIO-KEN',
        icon: '🔴',
        color: 0xFF0000,
        cooldown: 12,
        description: 'Speed boost + red aura',
        type: 'buff',
        range: 0,
        damage: 0
      },
      {
        id: 'instant_transmission',
        name: 'INSTANT TRANSMISSION',
        icon: '⚡',
        color: 0xFFD700,
        cooldown: 8,
        description: 'Teleport forward 8m',
        type: 'teleport',
        range: 8,
        damage: 0
      },
      {
        id: 'super_saiyan',
        name: 'SUPER SAIYAN',
        icon: '🌟',
        color: 0xFFFF00,
        cooldown: 25,
        description: 'Golden form - max speed + 8s',
        type: 'ultimate',
        range: 0,
        damage: 0
      }
    ]
  },
  saitama: {
    name: 'Saitama',
    skills: [
      {
        id: 'normal_punch',
        name: 'NORMAL PUNCH',
        icon: '👊',
        color: 0x808080,
        cooldown: 5,
        description: 'Quick punch - short range stun',
        type: 'melee',
        range: 2,
        damage: 0
      },
      {
        id: 'serious_punch',
        name: 'SERIOUS PUNCH',
        icon: '💢',
        color: 0xFF4500,
        cooldown: 15,
        description: 'Devastating punch - massive knockback',
        type: 'ultimate',
        range: 3,
        damage: 0
      },
      {
        id: 'consecutive_normal',
        name: 'CONSECUTIVE NORMAL',
        icon: '🥊',
        color: 0x8B0000,
        cooldown: 10,
        description: 'Rapid punches - multi-hit stun',
        type: 'combo',
        range: 2,
        damage: 0
      },
      {
        id: 'table_flip',
        name: 'TABLE FLIP',
        icon: '🪑',
        color: 0x8B4513,
        cooldown: 20,
        description: 'Environmental damage - area stun',
        type: 'aoe',
        range: 5,
        damage: 0
      }
    ]
  },
  gojo: {
    name: 'Gojo',
    skills: [
      {
        id: 'infinity',
        name: 'INFINITY',
        icon: '♾️',
        color: 0x9932CC,
        cooldown: 12,
        description: 'Barrier - block all tags for 4s',
        type: 'shield',
        range: 0,
        damage: 0
      },
      {
        id: 'red',
        name: 'RED',
        icon: '🔴',
        color: 0xFF0000,
        cooldown: 8,
        description: 'Repulsion force - push enemies',
        type: 'push',
        range: 6,
        damage: 0
      },
      {
        id: 'blue',
        name: 'BLUE',
        icon: '🔵',
        color: 0x0000FF,
        cooldown: 8,
        description: 'Attraction force - pull enemies',
        type: 'pull',
        range: 6,
        damage: 0
      },
      {
        id: 'hollow_purple',
        name: 'HOLLOW PURPLE',
        icon: '🟣',
        color: 0x800080,
        cooldown: 20,
        description: 'Fusion of Red + Blue - massive damage',
        type: 'ultimate',
        range: 10,
        damage: 0
      }
    ]
  },
  killua: {
    name: 'Killua',
    skills: [
      {
        id: 'godspeed',
        name: 'GODSPEED',
        icon: '⚡',
        color: 0xFFFFFF,
        cooldown: 10,
        description: 'Lightning speed - dash through enemies',
        type: 'dash',
        range: 10,
        damage: 0
      },
      {
        id: 'electric_palms',
        name: 'ELECTRIC PALMS',
        icon: '🤚',
        color: 0xFFFF00,
        cooldown: 6,
        description: 'Electric touch - short range stun',
        type: 'melee',
        range: 2,
        damage: 0
      },
      {
        id: 'yumi',
        name: 'YUMI',
        icon: '🏹',
        color: 0xC0C0C0,
        cooldown: 8,
        description: 'Assassin mode - invisible for 3s',
        type: 'stealth',
        range: 0,
        damage: 0
      },
      {
        id: 'lightning',
        name: 'LIGHTNING',
        icon: '🌩️',
        color: 0x4169E1,
        cooldown: 18,
        description: 'Full lightning - chain stun nearby',
        type: 'aoe',
        range: 4,
        damage: 0
      }
    ]
  }
};

export function getCharacterSkills(character) {
  return CHARACTER_SKILLS[character] || CHARACTER_SKILLS.naruto;
}

export function getSkill(character, skillId) {
  const charSkills = CHARACTER_SKILLS[character];
  if (!charSkills) return null;
  return charSkills.skills.find(s => s.id === skillId);
}
