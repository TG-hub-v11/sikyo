import { defineConfig } from 'vite';
export default defineConfig({
  root: 'client',
  server: { port: 5173, host: true },
  build: { outDir: '../dist', emptyOutDir: true },
  define: { __SERVER_URL__: JSON.stringify(process.env.SERVER_URL || 'http://localhost:3000') }
});
