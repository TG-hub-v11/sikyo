export const COLORS = {
  jeepneyRed: 0xE63946,
  sunshineYellow: 0xFFD23F,
  deepMidnight: 0x151923,
  tropicalGreen: 0x24A66A,
  skyBlue: 0x36A9E1,
  warmCream: 0xFFF5E1,
  white: 0xFFFFFF,
  css: {
    jeepneyRed: '#E63946',
    sunshineYellow: '#FFD23F',
    deepMidnight: '#151923',
    tropicalGreen: '#24A66A',
    skyBlue: '#36A9E1',
    warmCream: '#FFF5E1',
    white: '#FFFFFF'
  }
};

export const TEAMS = { RED: 'red', BLUE: 'blue' };

export const CONFIG = {
  ARENA_HALF: 28,          // arena extends -28..+28 in x/z
  BASE_RADIUS: 5,          // circular base zone radius
  BASE_Z: 22,              // bases at z = +/-22 (red at +z, blue at -z)
  TAG_RANGE: 2.2,          // auto-tag distance
  RESCUE_RANGE: 3.0,
  PLAYER_SPEED: 8,
  SPRINT_MULT: 1.5,
  JUMP_HEIGHT: 2.5,       // max jump height
  JUMP_DURATION: 0.6,     // jump duration in seconds
  TICK_RATE: 20,           // server snapshots per second
  CAPTURE_TARGET: 5,
  MATCH_TIME_SEC: 300,
  RESCUE_COOLDOWN_MS: 1000,
  TAG_COOLDOWN_MS: 500,
  REQUIRE_EMPTY_BASE_FOR_CAPTURE: true,
  MAX_PLAYERS_PER_ROOM: 12,
  // ---- Runes & skills ----
  DASH_COOLDOWN_MS: 6000,
  DASH_DIST: 6.5,
  STONE_RANGE: 10,
  STONE_HIT_RADIUS: 1.3,
  STONE_SPEED: 24,
  STONE_THROW_COOLDOWN_MS: 1500,
  BOMB_THROW_DIST: 6,
  BOMB_FUSE_MS: 800,
  BOMB_RADIUS: 4,
  STUN_MS: 2500,
  SWIFT_MULT: 1.55,
  SWIFT_MS: 8000,
  SHIELD_MS: 10000,
  GHOST_MS: 5000,
  RUNE_MAX_ACTIVE: 3,
  RUNE_RESPAWN_MS: 10000,
  // rune spawn points (mid-field, away from bases)
  RUNE_SPOTS: [
    { x: -12, z: 0 }, { x: 12, z: 0 },
    { x: 0, z: 8 }, { x: 0, z: -8 },
    { x: -7, z: 12 }, { x: 7, z: -12 }
  ]
};

export const RUNE_TYPES = {
  swift: { icon: '⚡', name: 'Sigla', desc: '+55% bilis, 8s' },
  dash: { icon: '💨', name: 'Harurot', desc: 'Dash refill + super dash' },
  stone: { icon: '🪨', name: 'Bato', desc: 'F = ranged tag (kailangan priority)' },
  bomb: { icon: '💣', name: 'Paputok', desc: 'F = stun blast 2.5s (no capture)' },
  shield: { icon: '🛡️', name: 'Kalasag', desc: 'Block 1 tag, 10s' },
  ghost: { icon: '👻', name: 'Multo', desc: 'Di mahuli 5s, di makahuli' }
};

export const PLAYER_STATES = { FREE: 'free', CAPTURED: 'captured' };

export const MICROCOPIES = [
  'Laro na, kabayan!',
  'Bantayan ang base!',
  'Sagipin ang tropa!',
  'Diskartehan mo!',
  'Uy, may papaplapit sa base!',
  'Bawi next game!',
  'Lupit mo, kabayan!'
];
