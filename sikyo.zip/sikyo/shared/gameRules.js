// Shared authoritative rules — imported by BOTH server and client (read-only on client).
// Departure-order tagging: earlier departure beats later departure.
import { CONFIG } from './constants.js';

export function dist2D(a, b) {
  const dx = a.x - b.x, dz = a.z - b.z;
  return Math.hypot(dx, dz);
}

export function baseCenter(team) {
  return team === 'red' ? { x: 0, z: CONFIG.BASE_Z } : { x: 0, z: -CONFIG.BASE_Z };
}

export function isInOwnBase(player) {
  const c = baseCenter(player.team);
  return dist2D(player.pos, c) <= CONFIG.BASE_RADIUS;
}

export function isInEnemyBase(player) {
  const c = baseCenter(player.team === 'red' ? 'blue' : 'red');
  return dist2D(player.pos, c) <= CONFIG.BASE_RADIUS;
}

export function isInBase(pos, team) {
  const c = baseCenter(team);
  return dist2D(pos, c) <= CONFIG.BASE_RADIUS;
}

// Can tagger legally tag target? Both must be FREE, opposing teams,
// within TAG_RANGE, and tagger.departureSeq > target.departureSeq
// (nahuling umalis ang nakakahuli: later leaver tags earlier leaver).
// Kung sino nauna umalis, siya ang pwedeng habulin (matataya).
// Pag bumalik sa sariling base, reset (seq = 0) — paglabas ulit,
// bago at mas huling seq, kaya makakahuli na.
// Players still inside their own base (seq === 0) cannot tag and cannot be tagged.
export function canTag(tagger, target, playersById) {
  if (!tagger || !target) return { ok: false, reason: 'missing-player' };
  if (tagger.id === target.id) return { ok: false, reason: 'self' };
  if (tagger.team === target.team) return { ok: false, reason: 'same-team' };
  if (tagger.state !== 'free' || target.state !== 'free') return { ok: false, reason: 'not-free' };
  if (!tagger.departureSeq || !target.departureSeq) return { ok: false, reason: 'in-base' };
  if (isGhost(tagger) || isGhost(target)) return { ok: false, reason: 'ghost' };
  if (hasShield(target)) return { ok: false, reason: 'shielded' };
  if (!(tagger.departureSeq > target.departureSeq)) return { ok: false, reason: 'no-priority' };
  const d = dist2D(tagger.pos, target.pos);
  if (d > CONFIG.TAG_RANGE) return { ok: false, reason: 'too-far', dist: d };
  const now = Date.now();
  if (now - (tagger.lastTagAt || 0) < CONFIG.TAG_COOLDOWN_MS) return { ok: false, reason: 'cooldown' };
  void playersById;
  return { ok: true, dist: d };
}

// Base capture: attacker must be FREE, inside enemy base, and
// (default competitive rule) no FREE defender of the base-owning team
// may remain. Returns {ok, reason}.
export function canCapture(attacker, allPlayers) {
  if (!attacker || attacker.state !== 'free') return { ok: false, reason: 'not-free' };
  if (!isInEnemyBase(attacker)) return { ok: false, reason: 'not-in-enemy-base' };
  if (CONFIG.REQUIRE_EMPTY_BASE_FOR_CAPTURE) {
    const baseOwner = attacker.team === 'red' ? 'blue' : 'red';
    const freeDefenders = allPlayers.filter(p => p.team === baseOwner && p.state === 'free');
    // Defenders count as "on base" only if inside their own base circle.
    const onBase = freeDefenders.filter(p => isInOwnBase(p));
    if (onBase.length > 0) return { ok: false, reason: 'defended', defenders: onBase.length };
  }
  return { ok: true };
}

// Rescue: rescuer FREE, same team as captured line owner; must be near the
// tail (last captured player) of the enemy-held line within RESCUE_RANGE.
export function rescueTargetFor(rescuer, allPlayers) {
  if (!rescuer || rescuer.state !== 'free') return null;
  // captured teammates held by enemy: state==='captured'
  const captured = allPlayers.filter(p => p.team === rescuer.team && p.state === 'captured');
  if (captured.length === 0) return null;
  // tail = most recently captured
  captured.sort((a, b) => (a.capturedAt || 0) - (b.capturedAt || 0));
  const tail = captured[captured.length - 1];
  const d = dist2D(rescuer.pos, tail.pos);
  if (d > CONFIG.RESCUE_RANGE) return null;
  return tail;
}

// ---- Runes & skills (server-authoritative, mirrored in practice) ----
export function isStunned(p, now = Date.now()) {
  return !!p && (p.stunUntil || 0) > now;
}
export function hasSwift(p, now = Date.now()) {
  return !!p && (p.swiftUntil || 0) > now;
}
export function hasShield(p, now = Date.now()) {
  return !!p && (p.shieldUntil || 0) > now && (p.shieldCharges || 0) > 0;
}
export function isGhost(p, now = Date.now()) {
  return !!p && (p.ghostUntil || 0) > now;
}
export function speedMult(p, now = Date.now()) {
  return hasSwift(p, now) ? CONFIG.SWIFT_MULT : 1;
}
// Dash displacement from facing rot, clamped to arena.
export function dashDest(pos, rot, dist = CONFIG.DASH_DIST) {
  return {
    x: Math.max(-CONFIG.ARENA_HALF, Math.min(CONFIG.ARENA_HALF, pos.x + Math.sin(rot) * dist)),
    z: Math.max(-CONFIG.ARENA_HALF, Math.min(CONFIG.ARENA_HALF, pos.z + Math.cos(rot) * dist))
  };
}
// Ranged tag via stone: same priority/state rules as canTag, minus distance
// (hit already confirmed by projectile collision).
export function canRangedTag(tagger, target) {
  if (!tagger || !target) return { ok: false, reason: 'missing-player' };
  if (tagger.id === target.id) return { ok: false, reason: 'self' };
  if (tagger.team === target.team) return { ok: false, reason: 'same-team' };
  if (tagger.state !== 'free' || target.state !== 'free') return { ok: false, reason: 'not-free' };
  if (!tagger.departureSeq || !target.departureSeq) return { ok: false, reason: 'in-base' };
  if (isGhost(tagger) || isGhost(target)) return { ok: false, reason: 'ghost' };
  if (hasShield(target)) return { ok: false, reason: 'shielded' };
  if (!(tagger.departureSeq > target.departureSeq)) return { ok: false, reason: 'no-priority' };
  return { ok: true };
}
// Bomb stun targets: free enemies within radius (no capture, stun only).
export function bombTargets(bomb, allPlayers) {
  return allPlayers.filter(p =>
    p.team !== bomb.team && p.state === 'free' &&
    dist2D(p.pos, bomb) <= CONFIG.BOMB_RADIUS
  );
}
export const RUNE_POOL = ['swift', 'dash', 'stone', 'bomb', 'shield', 'ghost'];
export function randomRune() {
  return RUNE_POOL[Math.floor(Math.random() * RUNE_POOL.length)];
}
// Elimination: a team with >=1 player in the match loses when ALL its
// players are captured. Returns 'red' | 'blue' | 'draw' | null.
// - null: no elimination (a team still has a free player, or team empty).
// - draw: both teams fully captured at the same time (rare, simultaneous tags).
export function checkElimination(allPlayers) {
  const reds = allPlayers.filter(p => p.team === 'red');
  const blues = allPlayers.filter(p => p.team === 'blue');
  if (reds.length === 0 || blues.length === 0) return null;
  const redWiped = reds.every(p => p.state === 'captured');
  const blueWiped = blues.every(p => p.state === 'captured');
  if (redWiped && blueWiped) return 'draw';
  if (blueWiped) return 'red';
  if (redWiped) return 'blue';
  return null;
}

export function safeSpawn(team, index = 0) {
  const c = baseCenter(team);
  const angle = (index / 6) * Math.PI * 2;
  return { x: c.x + Math.cos(angle) * 2.5, z: c.z + Math.sin(angle) * 2.5 };
}

export function lineSlot(baseOwnerTeam, slotIndex) {
  // Captured line forms beside the capturer's base: offset in +x direction.
  const c = baseCenter(baseOwnerTeam);
  return { x: c.x + 4.5 + slotIndex * 1.6, z: c.z - 1.5 };
}
