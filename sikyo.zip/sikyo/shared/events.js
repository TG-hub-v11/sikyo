// Socket.IO event names — single source of truth.
export const EVENTS = {
  // lobby
  CREATE_ROOM: 'room:create',
  JOIN_ROOM: 'room:join',
  QUICK_MATCH: 'room:quick',
  LEAVE_ROOM: 'room:leave',
  SET_TEAM: 'room:team',
  SET_READY: 'room:ready',
  ROOM_STATE: 'room:state',
  ERROR_MSG: 'error:msg',
  // match
  MATCH_START: 'match:start',
  MATCH_END: 'match:end',
  MATCH_TICK: 'match:tick',       // 20Hz snapshot server -> clients
  PLAYER_MOVE: 'player:move',     // client -> server input intent
  PLAYER_TAGGED: 'player:tagged', // server -> all
  PLAYER_RESCUED: 'player:rescued',
  PLAYER_DASH: 'player:dash',     // client -> server dash request
  PLAYER_DASHED: 'player:dashed', // server -> all dash confirm
  PLAYER_SKILL: 'player:skill',   // client -> server use held skill (F)
  STONE_THROWN: 'stone:thrown',
  BOMB_THROWN: 'bomb:thrown',
  BOMB_BOOM: 'bomb:boom',
  RUNE_SPAWNED: 'rune:spawned',
  RUNE_TAKEN: 'rune:taken',
  RUNE_GOT: 'rune:got',           // server -> picker only
  SHIELD_BLOCKED: 'shield:blocked',
  BASE_CAPTURED: 'base:captured',
  RESCUE_PROMPT: 'rescue:prompt',
  CHAT_MSG: 'chat:msg'
};
