# SIKYO: Agawan Base — LARO NA, PINOY!

3D Filipino .io browser game. Three.js frontend + Node/Socket.IO authoritative server + Vite.

## Quick start (local, free)

Requirements: Node 18+, modern browser (Chrome/Safari), same WiFi for phone testing.

```bash
cd sikyo
npm install
cp .env.example .env   # Windows: copy .env.example .env
```

Run **two terminals**:

```bash
# terminal 1 — multiplayer server (authoritative rules)
npm run dev:server
# -> http://localhost:3000/health should say {"ok":true}

# terminal 2 — game client
npm run dev:client
# -> http://localhost:5173
```

Open 2+ browser windows at http://localhost:5173 to test multiplayer:
Quick Match -> same room, pick teams, READY x2 -> countdown -> LARO!

Offline fallback: Lobby -> PRACTICE (OFFLINE) works with zero server.

## How to play (authentic rules)

- Umalis sa base para maglaro. **Nahuling umalis ang nakakahuli** — kung sino nauna, siya ang **taya (habulin)**.
- Auto-tag on proximity (2.2m). No tag button needed. Nasa base ka = safe, hindi makakahuli at hindi mahuhuli.
- Captured players form a line at capturer's base. Teammate touches tail + `E` = rescue whole line (*Sagipin ang tropa!*).
- Score only when enemy base has **no free defender** on it (configurable `REQUIRE_EMPTY_BASE_FOR_CAPTURE`).
- **Elimination:** pag nahuli lahat ng players ng isang team, talo sila agad (instant win, server + practice).
- First to 5 captures (or timeout) wins.

Controls: WASD/arrows move, Shift sprint, E rescue, Esc pause. Mobile: left joystick + RESCUE button.

## Project layout

- `client/` Vite + Three.js game (scene/arena.js, player/avatar.js, game/Game.js, network/socket.js, ui in index.html)
- `server/src/` authoritative Match (game/match.js), rooms (rooms/roomManager.js), socket routes (index.js)
- `shared/` single source of truth: gameRules.js, constants.js, events.js
- `tests/rules.test.js` — `npm test` (departure priority, base defense, rescue)

## Build + deploy

```bash
npm run build   # -> dist/ static frontend
npm start       # prod server (PORT env)
```

Deploy separately (free tier path):
- Frontend `dist/` -> Netlify / Vercel / GitHub Pages / Cloudflare Pages (set `SERVER_URL` env at build: `SERVER_URL=https://your-server.onrender.com vite build`).
- Server (needs persistent Node + WebSocket, **not** static hosting) -> Render / Railway / Fly.io / Koyeb free tier. Set `PORT`, `CLIENT_URL`, `CAPTURE_TARGET`, `MATCH_TIME_SEC`.
- Phone test: serve client on LAN (`vite --host`), open `http://<pc-ip>:5173` on mobile browser.

Limitations: free hosts sleep/idle — expect cold start. Socket.IO needs sticky sessions if scaled beyond 1 instance (keep 1 instance on free tier).

## What works now (Phase 1-4 playable)

- [x] 3D Pinoy arena (bases, flags, sari-sari store, houses, trees, fiesta banners, hoop)
- [x] Stylized avatars + name tags + run anim + captured pose + priority ring
- [x] Menu / How-to / Lobby (nick, teams, quick/create/join, ready, room code)
- [x] HUD (scores, timer, target, base warnings, rescue banner, sound/pause)
- [x] Server-authoritative: identity, teams, departureSeq, tag eligibility, captured/rescue, base defense, scoring, victory, rooms, interpolation, disconnect cleanup
- [x] Offline practice mode with bot
- [x] Mobile joystick + responsive + touch
- [ ] Rematch auto-reset (client button present, server rematch = ready again), leaderboard persistence, cosmetics shop — stubbed with toasts
