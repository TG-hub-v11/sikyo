import test from 'node:test';
import assert from 'node:assert/strict';
import { canTag, canCapture, canRangedTag, checkElimination, bombTargets, dashDest, isStunned, hasShield, isGhost, speedMult, rescueTargetFor, isInOwnBase } from '../shared/gameRules.js';
import { CONFIG } from '../shared/constants.js';

const P = (o) => ({ id: 'x', nick: 't', team: 'red', pos: { x: 0, z: 0 }, state: 'free', departureSeq: 1, lastTagAt: 0, ...o });

test('departure-order: later tags earlier (nahuli nakakahuli), not reverse', () => {
  const early = P({ id: 'a', team: 'red', pos: { x: 0, z: 0 }, departureSeq: 1 });
  const late = P({ id: 'b', team: 'blue', pos: { x: 1, z: 0 }, departureSeq: 2 });
  assert.equal(canTag(late, early, {}).ok, true);
  assert.equal(canTag(early, late, {}).ok, false);
});

test('base return resets: re-leaving gives later seq and flips priority', () => {
  // simulate: A left early (seq 1), B left later (seq 2) -> B can tag A
  const aEarly = P({ id: 'a', team: 'red', pos: { x: 0, z: 0 }, departureSeq: 1 });
  const bLate = P({ id: 'b', team: 'blue', pos: { x: 1, z: 0 }, departureSeq: 2 });
  assert.equal(canTag(bLate, aEarly, {}).ok, true);
  // A runs back to base -> seq reset to 0, cannot tag/be tagged while inside
  aEarly.departureSeq = 0;
  assert.equal(canTag(bLate, aEarly, {}).ok, false);
  assert.equal(canTag(aEarly, bLate, {}).ok, false);
  // A leaves again -> newest seq 3, now A can tag B (nakataya na!)
  aEarly.departureSeq = 3;
  assert.equal(canTag(aEarly, bLate, {}).ok, true);
  assert.equal(canTag(bLate, aEarly, {}).ok, false);
});

test('in-base players cannot tag', () => {
  const a = P({ id: 'a', team: 'red', departureSeq: 0 });
  const b = P({ id: 'b', team: 'blue', pos: { x: 1, z: 0 }, departureSeq: 5 });
  assert.equal(canTag(a, b, {}).ok, false);
});

test('capture blocked by defender on base', () => {
  CONFIG.REQUIRE_EMPTY_BASE_FOR_CAPTURE = true;
  const attacker = P({ id: 'a', team: 'red', pos: { x: 0, z: -22 }, state: 'free', departureSeq: 3 });
  const defender = P({ id: 'd', team: 'blue', pos: { x: 1, z: -22 }, state: 'free', departureSeq: 4 });
  assert.equal(canCapture(attacker, [attacker, defender]).ok, false);
  defender.pos = { x: 0, z: 10 };
  assert.equal(canCapture(attacker, [attacker, defender]).ok, true);
});

test('rescue finds tail within range', () => {
  const resc = P({ id: 'r', team: 'red', pos: { x: 4, z: 20 }, departureSeq: 9 });
  const cap = P({ id: 'c', team: 'red', pos: { x: 5, z: 20 }, state: 'captured', capturedAt: 1 });
  assert.ok(rescueTargetFor(resc, [resc, cap]));
  cap.pos = { x: 40, z: 40 };
  assert.equal(rescueTargetFor(resc, [resc, cap]), null);
});

test('bases at opposite ends', () => {
  assert.ok(isInOwnBase(P({ team: 'red', pos: { x: 0, z: 22 } })));
  assert.ok(!isInOwnBase(P({ team: 'red', pos: { x: 0, z: 0 } })));
});

test('elimination: whole team captured loses', () => {
  const r1 = P({ id: 'r1', team: 'red', state: 'captured' });
  const r2 = P({ id: 'r2', team: 'red', state: 'captured' });
  const b1 = P({ id: 'b1', team: 'blue', state: 'free', departureSeq: 9 });
  assert.equal(checkElimination([r1, r2, b1]), 'blue');
  b1.state = 'captured';
  r1.state = 'free';
  assert.equal(checkElimination([r1, r2, b1]), 'red');
});

test('elimination: no wipe, no winner', () => {
  const r1 = P({ id: 'r1', team: 'red', state: 'free', departureSeq: 1 });
  const b1 = P({ id: 'b1', team: 'blue', state: 'captured' });
  const b2 = P({ id: 'b2', team: 'blue', state: 'free', departureSeq: 2 });
  assert.equal(checkElimination([r1, b1, b2]), null);
});

test('elimination: both wiped is draw', () => {
  const r1 = P({ id: 'r1', team: 'red', state: 'captured' });
  const b1 = P({ id: 'b1', team: 'blue', state: 'captured' });
  assert.equal(checkElimination([r1, b1]), 'draw');
});

test('runes: shield blocks tag, consumes charge', () => {
  const now = Date.now();
  const hunter = P({ id: 'h', team: 'red', pos: { x: 0, z: 0 }, departureSeq: 5 });
  const prey = P({ id: 'p', team: 'blue', pos: { x: 1, z: 0 }, departureSeq: 2,
    shieldUntil: now + 10000, shieldCharges: 1 });
  assert.ok(hasShield(prey, now));
  assert.equal(canTag(hunter, prey, {}).ok, false);
  assert.equal(canTag(hunter, prey, {}).reason, 'shielded');
  assert.equal(canRangedTag(hunter, prey).ok, false);
});

test('runes: ghost untaggable and cannot tag', () => {
  const now = Date.now();
  const hunter = P({ id: 'h', team: 'red', pos: { x: 0, z: 0 }, departureSeq: 5, ghostUntil: now + 5000 });
  const prey = P({ id: 'p', team: 'blue', pos: { x: 1, z: 0 }, departureSeq: 2 });
  assert.ok(isGhost(hunter, now));
  assert.equal(canTag(hunter, prey, {}).ok, false);
  assert.equal(canTag(prey, hunter, {}).ok, false);
});

test('runes: swift multiplies speed, stun blocks priority', () => {
  const now = Date.now();
  const fast = P({ swiftUntil: now + 8000 });
  assert.equal(speedMult(fast, now), CONFIG.SWIFT_MULT);
  assert.equal(speedMult(P({}), now), 1);
  assert.ok(isStunned(P({ stunUntil: now + 1000 }), now));
  assert.ok(!isStunned(P({}), now));
});

test('runes: dash destination clamped to arena', () => {
  const d = dashDest({ x: 26, z: 26 }, Math.atan2(1, 1), 6.5);
  assert.ok(d.x <= CONFIG.ARENA_HALF && d.z <= CONFIG.ARENA_HALF);
});

test('runes: bomb hits enemies in radius only, no capture', () => {
  const foe = P({ id: 'f', team: 'blue', pos: { x: 1, z: 0 } });
  const mate = P({ id: 'm', team: 'red', pos: { x: 1, z: 0 } });
  const far = P({ id: 'x', team: 'blue', pos: { x: 20, z: 20 } });
  const hits = bombTargets({ x: 0, z: 0, team: 'red' }, [foe, mate, far]);
  assert.deepEqual(hits.map(p => p.id), ['f']);
});
