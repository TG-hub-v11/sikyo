import { Match } from '../game/match.js';
import { CONFIG } from '../../../shared/constants.js';

const rooms = new Map(); // code -> { match, ready:Set }

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c = '';
  for (let i = 0; i < 4; i++) c += chars[Math.floor(Math.random() * chars.length)];
  return c;
}

export function getOrCreateRoom(code, io, opts) {
  if (rooms.has(code)) return rooms.get(code);
  const match = new Match(code, io, opts);
  const rec = { match, createdAt: Date.now() };
  rooms.set(code, rec);
  return rec;
}

export function createRoom(io, opts) {
  let code = makeCode();
  while (rooms.has(code)) code = makeCode();
  return getOrCreateRoom(code, io, opts).match;
}

export function findQuickRoom(io, opts) {
  for (const [, rec] of rooms) {
    if (rec.match.status === 'lobby' && rec.match.players.size < (opts?.maxPlayers || CONFIG.MAX_PLAYERS_PER_ROOM)) {
      return rec.match;
    }
  }
  return createRoom(io, opts);
}

export function getRoom(code) {
  return rooms.get(code);
}

export function deleteIfEmpty(code) {
  const rec = rooms.get(code);
  if (rec && rec.match.players.size === 0) {
    if (rec.match.timer) clearInterval(rec.match.timer);
    rooms.delete(code);
  }
}
