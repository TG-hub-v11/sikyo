// Authoritative match: players, departure order, tags, rescues, captures, runes.
import { CONFIG } from '../../../shared/constants.js';
import { canTag, canCapture, canRangedTag, checkElimination, bombTargets, dashDest, isStunned, hasSwift, hasShield, isGhost, speedMult, randomRune, rescueTargetFor, isInOwnBase, safeSpawn, lineSlot } from '../../../shared/gameRules.js';
let seqCounter = 1;
export class Match {
  constructor(roomCode, io, opts = {}) {
    this.roomCode = roomCode; this.io = io;
    this.players = new Map();
    this.scores = { red: 0, blue: 0 };
    this.stats = {};
    this.status = 'lobby';
    this.captureTarget = opts.captureTarget || CONFIG.CAPTURE_TARGET;
    this.timeLeft = opts.matchTimeSec || CONFIG.MATCH_TIME_SEC;
    this.baseTime = this.timeLeft;
    this.tickMs = 1000 / CONFIG.TICK_RATE;
    this.timer = null; this.countdown = 0; this.winner = null;
    this.runes = []; // {id,x,z,type}
    this.runeSeq = 1;
    this.stones = []; // projectiles {id,ownerId,team,x,z,dx,dz}
    this.stoneSeq = 1;
    this.bombs = []; // {id,ownerId,team,x,z,explodeAt}
    this.bombSeq = 1;
  }
  addPlayer(socketId, nick, team, species = 'fox') {
    const count = [...this.players.values()].filter(p => p.team === team).length;
    const pos = safeSpawn(team, count);
    const p = { id: socketId, nick, team, species, pos: { ...pos }, rot: team === 'red' ? Math.PI : 0,
      state: 'free', departureSeq: 0, wasInBase: true, lastTagAt: 0, lastRescueAt: 0,
      capturedAt: 0, sprint: false, moving: false, ready: false,
      stunUntil: 0, swiftUntil: 0, shieldUntil: 0, shieldCharges: 0, ghostUntil: 0,
      dashReadyAt: 0, lastDashAt: 0, lastStoneAt: 0, invulnUntil: 0,
      skill: null, skillCount: 0, jumping: false, jumpStartedAt: 0 };
    this.players.set(socketId, p);
    this.stats[socketId] = { tags: 0, rescues: 0, captures: 0, nick };
    return p;
  }
  removePlayer(socketId) { this.players.delete(socketId); }
  setTeam(socketId, team) {
    const p = this.players.get(socketId);
    if (!p || this.status !== 'lobby') return;
    p.team = team; p.pos = safeSpawn(team, 0);
    p.departureSeq = 0; p.wasInBase = true; p.state = 'free';
  }
  startCountdown(seconds = 3) {
    if (this.status !== 'lobby') return;
    this.status = 'countdown'; this.countdown = seconds;
    this.io.to(this.roomCode).emit('match:start', { countdown: seconds, roomCode: this.roomCode });
    const iv = setInterval(() => {
      this.countdown -= 1;
      this.io.to(this.roomCode).emit('match:start', { countdown: this.countdown, roomCode: this.roomCode });
      if (this.countdown <= 0) { clearInterval(iv); this.startPlay(); }
    }, 1000);
  }
  startPlay() {
    this.status = 'playing'; this.lastTick = Date.now();
    this.runes = []; this.stones = []; this.bombs = [];
    this._lastRune = 0;
    this.timer = setInterval(() => this.tick(), this.tickMs);
    this.io.to(this.roomCode).emit('match:start', { countdown: 0, go: true, roomCode: this.roomCode });
  }
  applyMove(socketId, input) {
    const p = this.players.get(socketId);
    if (!p || this.status !== 'playing' || p.state !== 'free') return;
    const now = Date.now();
    if (isStunned(p, now)) { p.moving = false; return; }
    let dx = Number(input?.dx) || 0, dz = Number(input?.dz) || 0;
    const mag = Math.hypot(dx, dz);
    if (mag > 1) { dx /= mag; dz /= mag; }
    const speed = CONFIG.PLAYER_SPEED * (input?.sprint ? CONFIG.SPRINT_MULT : 1) * speedMult(p, now);
    const dt = 1 / CONFIG.TICK_RATE;
    p.pos.x = Math.max(-CONFIG.ARENA_HALF, Math.min(CONFIG.ARENA_HALF, p.pos.x + dx * speed * dt));
    p.pos.z = Math.max(-CONFIG.ARENA_HALF, Math.min(CONFIG.ARENA_HALF, p.pos.z + dz * speed * dt));
    if (mag > 0.05) p.rot = Math.atan2(dx, dz);
    p.moving = mag > 0.05; p.sprint = !!input?.sprint;
    // Handle jump
    if (input?.jump && !p.jumping) {
      p.jumping = true;
      p.jumpStartedAt = now;
    }
    // Update jump state
    if (p.jumping) {
      const jumpElapsed = (now - p.jumpStartedAt) / 1000;
      if (jumpElapsed >= CONFIG.JUMP_DURATION) {
        p.jumping = false;
      }
    }
    const inBase = isInOwnBase(p);
    if (p.wasInBase && !inBase) { p.departureSeq = seqCounter++; p.departedAt = Date.now(); }
    if (inBase && !p.wasInBase) { p.wasInBase = true; p.departureSeq = 0; }
    else if (!inBase) { p.wasInBase = false; }
  }
  tryRescue(rescuerId) {
    const r = this.players.get(rescuerId);
    if (!r || this.status !== 'playing') return null;
    const now = Date.now();
    if (isStunned(r, now)) return null;
    if (now - (r.lastRescueAt || 0) < CONFIG.RESCUE_COOLDOWN_MS) return null;
    const all = [...this.players.values()];
    const tail = rescueTargetFor(r, all);
    if (!tail) return null;
    r.lastRescueAt = now;
    const freed = all.filter(p => p.team === r.team && p.state === 'captured');
    freed.forEach((p, i) => {
      p.state = 'free'; p.capturedAt = 0;
      p.pos = { ...safeSpawn(p.team, i) };
      p.wasInBase = true; p.departureSeq = 0;
    });
    if (this.stats[rescuerId]) this.stats[rescuerId].rescues += freed.length;
    this.io.to(this.roomCode).emit('player:rescued', {
      rescuer: { id: r.id, nick: r.nick, team: r.team },
      freed: freed.map(p => ({ id: p.id, nick: p.nick })), text: 'Sagipin ang tropa!'
    });
    return freed;
  }
  tryDash(socketId) {
    const p = this.players.get(socketId);
    if (!p || this.status !== 'playing' || p.state !== 'free') return false;
    const now = Date.now();
    if (isStunned(p, now)) return false;
    if (now < (p.dashReadyAt || 0)) return false;
    if (!p.departureSeq) return false;
    const d = dashDest(p.pos, p.rot);
    p.pos = { ...d };
    p.lastDashAt = now;
    p.dashReadyAt = now + (p.dashBonusUntil > now ? 0 : CONFIG.DASH_COOLDOWN_MS);
    if (p.dashBonusUntil > now) p.dashBonusUntil = 0;
    this.io.to(this.roomCode).emit('player:dashed', {
      id: p.id, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2), text: p.nick + ' humarurot! 💨'
    });
    return true;
  }
  useSkill(socketId) {
    const p = this.players.get(socketId);
    if (!p || this.status !== 'playing' || p.state !== 'free') return false;
    const now = Date.now();
    if (isStunned(p, now) || !p.departureSeq) return false;
    if (p.skill === 'stone' && p.skillCount > 0) {
      if (now - (p.lastStoneAt || 0) < CONFIG.STONE_THROW_COOLDOWN_MS) return false;
      p.lastStoneAt = now;
      p.skillCount -= 1; if (p.skillCount <= 0) p.skill = null;
      this.stones.push({ id: 's' + (this.stoneSeq++), ownerId: p.id, team: p.team,
        x: p.pos.x, z: p.pos.z, dx: Math.sin(p.rot), dz: Math.cos(p.rot) });
      this.io.to(this.roomCode).emit('stone:thrown', { ownerId: p.id, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2) });
      return true;
    }
    if (p.skill === 'bomb' && p.skillCount > 0) {
      p.skillCount -= 1; if (p.skillCount <= 0) p.skill = null;
      const d = CONFIG.BOMB_THROW_DIST;
      const bx = Math.max(-28, Math.min(28, p.pos.x + Math.sin(p.rot) * d));
      const bz = Math.max(-28, Math.min(28, p.pos.z + Math.cos(p.rot) * d));
      this.bombs.push({ id: 'b' + (this.bombSeq++), ownerId: p.id, team: p.team,
        x: +bx.toFixed(2), z: +bz.toFixed(2), explodeAt: now + CONFIG.BOMB_FUSE_MS });
      this.io.to(this.roomCode).emit('bomb:thrown', { ownerId: p.id, x: +bx.toFixed(2), z: +bz.toFixed(2) });
      return true;
    }
    return false;
  }
  pickupRune(p, rune) {
    const now = Date.now();
    const idx = this.runes.indexOf(rune);
    if (idx >= 0) this.runes.splice(idx, 1);
    this.io.to(this.roomCode).emit('rune:taken', { id: rune.id, by: p.nick, type: rune.type });
    if (rune.type === 'swift') p.swiftUntil = now + CONFIG.SWIFT_MS;
    else if (rune.type === 'dash') { p.dashReadyAt = 0; p.dashBonusUntil = now + 15000; }
    else if (rune.type === 'stone') { p.skill = 'stone'; p.skillCount = 1; }
    else if (rune.type === 'bomb') { p.skill = 'bomb'; p.skillCount = 1; }
    else if (rune.type === 'shield') { p.shieldUntil = now + CONFIG.SHIELD_MS; p.shieldCharges = 1; }
    else if (rune.type === 'ghost') p.ghostUntil = now + CONFIG.GHOST_MS;
    this.io.to(p.id).emit('rune:got', { type: rune.type, skill: p.skill, count: p.skillCount });
  }
  ensureRunes() {
    const now = Date.now();
    if (this.status !== 'playing') return;
    if (!this._lastRune || now - this._lastRune > CONFIG.RUNE_RESPAWN_MS) {
      this._lastRune = now;
      if (this.runes.length < CONFIG.RUNE_MAX_ACTIVE) {
        const occupied = new Set(this.runes.map(r => r.spot));
        const free = CONFIG.RUNE_SPOTS.map((s, i) => i).filter(i => !occupied.has(i));
        if (free.length) {
          const si = free[Math.floor(Math.random() * free.length)];
          const spot = CONFIG.RUNE_SPOTS[si];
          this.runes.push({ id: 'r' + (this.runeSeq++), spot: si, x: spot.x, z: spot.z, type: randomRune() });
          this.io.to(this.roomCode).emit('rune:spawned', { runes: this.runes });
        }
      }
    }
    for (const p of this.players.values()) {
      if (p.state !== 'free' || !p.departureSeq) continue;
      const hit = this.runes.find(r => Math.hypot(r.x - p.pos.x, r.z - p.pos.z) < 1.4);
      if (hit) this.pickupRune(p, hit);
    }
  }
  stepFx(dt) {
    const step = CONFIG.STONE_SPEED * dt;
    for (const s of [...this.stones]) {
      s.x += s.dx * step; s.z += s.dz * step;
      if (Math.abs(s.x) > CONFIG.ARENA_HALF + 2 || Math.abs(s.z) > CONFIG.ARENA_HALF + 2) {
        this.stones = this.stones.filter(x => x !== s); continue;
      }
      const owner = this.players.get(s.ownerId);
      for (const t of this.players.values()) {
        if (!owner || t.team === s.team || t.state !== 'free' || !t.departureSeq) continue;
        if (Math.hypot(t.pos.x - s.x, t.pos.z - s.z) > CONFIG.STONE_HIT_RADIUS) continue;
        const res = canRangedTag(owner, t);
        this.stones = this.stones.filter(x => x !== s);
        if (!res.ok) {
          if (res.reason === 'shielded') {
            t.shieldCharges = 0; t.shieldUntil = 0;
            this.io.to(this.roomCode).emit('shield:blocked', { id: t.id, text: t.nick + ' nasalag ang bato! 🛡️' });
          }
          break;
        }
        t.state = 'captured'; t.capturedAt = Date.now();
        const line = [...this.players.values()].filter(p => p.team === t.team && p.state === 'captured');
        t.pos = { ...lineSlot(owner.team, Math.max(0, line.length - 1)) };
        t.wasInBase = false;
        if (this.stats[owner.id]) this.stats[owner.id].tags += 1;
        owner.skillCount = 0; owner.skill = null;
        this.io.to(this.roomCode).emit('player:tagged', {
          tagger: { id: owner.id, nick: owner.nick, team: owner.team },
          target: { id: t.id, nick: t.nick, team: t.team },
          text: owner.nick + ' binato si ' + t.nick + '! 🪨', ranged: true
        });
        break;
      }
    }
    const now = Date.now();
    for (const b of [...this.bombs]) {
      if (now < b.explodeAt) continue;
      this.bombs = this.bombs.filter(x => x !== b);
      const owner = this.players.get(b.ownerId);
      const victims = bombTargets({ x: b.x, z: b.z, team: b.team }, [...this.players.values()])
        .filter(p => now > (p.invulnUntil || 0));
      for (const v of victims) {
        v.stunUntil = now + CONFIG.STUN_MS;
        v.invulnUntil = now + CONFIG.STUN_MS + 1500;
      }
      this.io.to(this.roomCode).emit('bomb:boom', {
        x: b.x, z: b.z, by: owner?.nick || '?',
        stunned: victims.map(v => ({ id: v.id, nick: v.nick })),
        text: victims.length ? 'BOOM! Na-stun: ' + victims.map(v => v.nick).join(', ') + ' 💣' : 'BOOM! Walang tinamaan 💣'
      });
    }
  }
  tick() {
    if (this.status !== 'playing') return;
    const now = Date.now();
    const dt = (now - (this.lastTick || now)) / 1000;
    this.lastTick = now; this.timeLeft -= dt;
    this.ensureRunes();
    this.stepFx(dt);
    // invuln expiry cleanup happens implicitly via timestamp checks
    const all = [...this.players.values()];
    const byId = Object.fromEntries(all.map(p => [p.id, p]));
    for (const a of all) {
      if (a.state !== 'free' || !a.departureSeq) continue;
      if (isStunned(a, now) || isGhost(a, now)) continue;
      for (const b of all) {
        if (b.state !== 'free' || !b.departureSeq) continue;
        if (isGhost(b, now)) continue;
        if (a.team === b.team) continue;
        const res = canTag(a, b, byId);
        if (!res.ok && res.reason === 'shielded') {
          b.shieldCharges = 0; b.shieldUntil = 0;
          this.io.to(this.roomCode).emit('shield:blocked', { id: b.id, text: b.nick + ' nasalag! 🛡️' });
          continue;
        }
        if (res.ok) {
          b.state = 'captured'; b.capturedAt = Date.now(); a.lastTagAt = Date.now();
          const line = all.filter(p => p.team === b.team && p.state === 'captured');
          b.pos = { ...lineSlot(a.team, Math.max(0, line.length - 1)) };
          b.wasInBase = false;
          if (this.stats[a.id]) this.stats[a.id].tags += 1;
          this.io.to(this.roomCode).emit('player:tagged', {
            tagger: { id: a.id, nick: a.nick, team: a.team },
            target: { id: b.id, nick: b.nick, team: b.team }, text: a.nick + ' hinuli si ' + b.nick + '!'
          });
          break;
        }
      }
    }
    // Elimination: whole team captured = that team loses immediately.
    const wiped = checkElimination([...this.players.values()]);
    if (wiped) {
      if (wiped === 'draw') return this.end('draw', ' Parehong team naubos — draw!');
      const loser = wiped === 'red' ? 'blue' : 'red';
      return this.end(wiped, ' Naubos ang Team ' + loser.toUpperCase() + ' — lahat nahuli!');
    }
    const snap = [...this.players.values()];
    for (const p of snap) {
      if (p.state !== 'free' || !p.departureSeq) continue;
      if (isGhost(p, now)) continue; // multo can't capture — unfair
      const cap = canCapture(p, snap);
      if (cap.ok) {
        this.scores[p.team] += 1;
        if (this.stats[p.id]) this.stats[p.id].captures += 1;
        this.io.to(this.roomCode).emit('base:captured', {
          by: { id: p.id, nick: p.nick, team: p.team },
          scores: { ...this.scores }, target: this.captureTarget,
          text: 'Lupit mo, kabayan! ' + p.nick + ' nakalusot!'
        });
        p.pos = safeSpawn(p.team, 0); p.departureSeq = 0; p.wasInBase = true;
        if (this.scores[p.team] >= this.captureTarget) return this.end(p.team);
      }
    }
    for (const r of this.players.values()) {
      if (r.state !== 'free') continue;
      const tail = rescueTargetFor(r, [...this.players.values()]);
      if (tail) this.io.to(r.id).emit('rescue:prompt', { tailId: tail.id, text: 'Sagipin ang tropa! (E)' });
    }
    if (this.timeLeft <= 0) {
      const w = this.scores.red === this.scores.blue ? 'draw' : (this.scores.red > this.scores.blue ? 'red' : 'blue');
      return this.end(w);
    }
    this.io.to(this.roomCode).emit('match:tick', {
      players: [...this.players.values()].map(p => ({
        id: p.id, nick: p.nick, team: p.team, species: p.species, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2),
        rot: +p.rot.toFixed(2), state: p.state, seq: p.departureSeq, moving: p.moving, sprint: p.sprint,
        stun: isStunned(p, now), swift: hasSwift(p, now), shield: hasShield(p, now), ghost: isGhost(p, now),
        dashReady: now >= (p.dashReadyAt || 0), skill: p.skill, skillCount: p.skillCount,
        jumping: p.jumping, jumpProgress: p.jumping ? Math.min(1, (now - p.jumpStartedAt) / 1000 / CONFIG.JUMP_DURATION) : 0
      })),
      runes: this.runes.map(r => ({ id: r.id, x: r.x, z: r.z, type: r.type })),
      stones: this.stones.map(s => ({ id: s.id, x: +s.x.toFixed(2), z: +s.z.toFixed(2) })),
      bombs: this.bombs.map(b => ({ id: b.id, x: b.x, z: b.z })),
      scores: { ...this.scores }, target: this.captureTarget,
      timeLeft: Math.ceil(this.timeLeft), status: this.status
    });
  }
  end(winner, extraText = '') {
    if (this.status === 'ended') return;
    this.status = 'ended'; this.winner = winner;
    if (this.timer) clearInterval(this.timer);
    this.io.to(this.roomCode).emit('match:end', {
      winner, scores: { ...this.scores },
      reason: extraText ? 'elimination' : (this.timeLeft <= 0 ? 'time' : 'target'),
      stats: Object.entries(this.stats).map(([id, s]) => ({ id, ...s })),
      rematchIn: 5,
      text: (winner === 'draw' ? 'Bawi next game!' : 'Panalo ang Team ' + String(winner).toUpperCase() + '!') + extraText +
        ' Balik base lahat — bagong laro in 5s!'
    });
    // Auto-rematch: reset lahat pa-base, bagong round pagkatapos ng 5s.
    this.rematchTimer = setTimeout(() => this.resetForRematch(), 5000);
  }
  resetForRematch() {
    if (this.players.size === 0) { this.status = 'lobby'; return; }
    const reds = [...this.players.values()].filter(p => p.team === 'red');
    const blues = [...this.players.values()].filter(p => p.team === 'blue');
    reds.forEach((p, i) => this.resetPlayer(p, i));
    blues.forEach((p, i) => this.resetPlayer(p, i));
    this.scores = { red: 0, blue: 0 };
    this.timeLeft = this.baseTime || this.timeLeft;
    this.winner = null;
    for (const id of Object.keys(this.stats)) {
      this.stats[id].tags = 0; this.stats[id].rescues = 0; this.stats[id].captures = 0;
    }
    this.io.to(this.roomCode).emit('room:state', this.lobbyState());
    this.io.to(this.roomCode).emit('match:rematch', {
      text: 'Balik base lahat — bagong laro! Laro na, kabayan!',
      players: [...this.players.values()].map(p => ({ id: p.id, nick: p.nick, team: p.team, species: p.species }))
    });
    this.status = 'lobby';
    this.startCountdown(3);
  }
  resetPlayer(p, index) {
    p.pos = safeSpawn(p.team, index);
    p.state = 'free'; p.departureSeq = 0; p.wasInBase = true;
    p.lastTagAt = 0; p.lastRescueAt = 0; p.capturedAt = 0;
    p.moving = false; p.sprint = false;
    p.rot = p.team === 'red' ? Math.PI : 0;
    p.ready = true;
    p.stunUntil = 0; p.swiftUntil = 0; p.shieldUntil = 0; p.shieldCharges = 0;
    p.ghostUntil = 0; p.dashReadyAt = 0; p.dashBonusUntil = 0;
    p.lastDashAt = 0; p.lastStoneAt = 0; p.invulnUntil = 0;
    p.skill = null; p.skillCount = 0;
    p.jumping = false; p.jumpStartedAt = 0;
  }
  lobbyState() {
    return { roomCode: this.roomCode, status: this.status, scores: this.scores,
      target: this.captureTarget, timeLeft: Math.ceil(this.timeLeft),
      players: [...this.players.values()].map(p => ({ id: p.id, nick: p.nick, team: p.team, species: p.species, state: p.state, ready: !!p.ready })) };
  }
}
