import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import { Server } from 'socket.io';
import { createRoom, findQuickRoom, getRoom, deleteIfEmpty } from './rooms/roomManager.js';
import { cleanNickname, cleanTeam, cleanSpecies, makeRateLimiter } from './security/validate.js';
import { CONFIG } from '../../shared/constants.js';

const PORT = process.env.PORT || 3000;
const app = express();
app.use(cors());
app.get('/health', (req, res) => res.json({ ok: true, game: 'SIKYO' }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });
const sockRoom = new Map();

function target(opts, fallback) {
  const n = Number(opts ?? fallback);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}
function opts() {
  return {
    captureTarget: target(process.env.CAPTURE_TARGET, CONFIG.CAPTURE_TARGET),
    matchTimeSec: target(process.env.MATCH_TIME_SEC, CONFIG.MATCH_TIME_SEC),
    maxPlayers: CONFIG.MAX_PLAYERS_PER_ROOM
  };
}
function state(m) { return m.lobbyState(); }

io.on('connection', (socket) => {
  const moveLimit = makeRateLimiter(40, 1000);
  socket.on('room:create', (data = {}) => {
    const m = createRoom(io, opts());
    join(socket, m, data);
  });
  socket.on('room:quick', (data = {}) => {
    const m = findQuickRoom(io, opts());
    join(socket, m, data);
  });
  socket.on('room:join', (data = {}) => {
    const rec = getRoom(String(data.roomCode || '').toUpperCase());
    if (!rec) return socket.emit('error:msg', { text: 'Room not found, kabayan!' });
    if (rec.match.players.size >= CONFIG.MAX_PLAYERS_PER_ROOM)
      return socket.emit('error:msg', { text: 'Puno na ang room!' });
    join(socket, rec.match, data);
  });
  function join(socket, m, data) {
    const nick = cleanNickname(data.nick);
    const species = cleanSpecies(data.species);
    let team = cleanTeam(data.team);
    if (!team) {
      const r = [...m.players.values()].filter(p => p.team === 'red').length;
      const b = [...m.players.values()].filter(p => p.team === 'blue').length;
      team = r <= b ? 'red' : 'blue';
    }
    socket.join(m.roomCode);
    sockRoom.set(socket.id, m.roomCode);
    m.addPlayer(socket.id, nick, team, species);
    io.to(m.roomCode).emit('room:state', state(m));
  }
  socket.on('room:team', (data = {}) => {
    const m = getSockMatch(socket);
    if (!m) return;
    const t = cleanTeam(data.team);
    const sp = data.species ? cleanSpecies(data.species) : null;
    if (t) {
      m.setTeam(socket.id, t);
      if (sp) { const p = m.players.get(socket.id); if (p) p.species = sp; }
      io.to(m.roomCode).emit('room:state', state(m));
    } else if (sp) {
      const p = m.players.get(socket.id); if (p) p.species = sp;
      io.to(m.roomCode).emit('room:state', state(m));
    }
  });
  socket.on('room:ready', (data = {}) => {
    const m = getSockMatch(socket);
    if (!m) return;
    const p = m.players.get(socket.id);
    if (!p) return;
    p.ready = !!data.ready;
    io.to(m.roomCode).emit('room:state', state(m));
    const all = [...m.players.values()];
    if (all.length >= 2 && all.every(x => x.ready)) m.startCountdown(3);
  });
  socket.on('room:leave', () => leave(socket));
  socket.on('player:move', (input = {}) => {
    if (!moveLimit()) return;
    const m = getSockMatch(socket);
    if (m) m.applyMove(socket.id, input);
  });
  socket.on('player:rescue', () => {
    const m = getSockMatch(socket);
    if (m) m.tryRescue(socket.id);
  });
  socket.on('player:dash', () => {
    const m = getSockMatch(socket);
    if (m) m.tryDash(socket.id);
  });
  socket.on('player:skill', () => {
    const m = getSockMatch(socket);
    if (m) m.useSkill(socket.id);
  });
  socket.on('chat:msg', (d = {}) => {
    const m = getSockMatch(socket);
    if (!m) return;
    const p = m.players.get(socket.id);
    const text = String(d.text || '').slice(0, 80);
    if (text) io.to(m.roomCode).emit('chat:msg', { nick: p?.nick || '?', team: p?.team, text });
  });
  socket.on('disconnect', () => leave(socket));
  function getSockMatch(s) {
    const code = sockRoom.get(s.id);
    if (!code) return null;
    const rec = getRoom(code);
    return rec ? rec.match : null;
  }
  function leave(s) {
    const code = sockRoom.get(s.id);
    if (!code) return;
    const rec = getRoom(code);
    if (rec) {
      rec.match.removePlayer(s.id);
      io.to(code).emit('room:state', state(rec.match));
      deleteIfEmpty(code);
    }
    sockRoom.delete(s.id);
    s.leave(code);
  }
});

server.listen(PORT, () => console.log('[SIKYO] server on :' + PORT));
