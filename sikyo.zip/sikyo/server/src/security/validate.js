// Minimal input validation / anti-cheat helpers.
const NICK_RE = /^[\p{L}\p{N} _-]{1,16}$/u;

export function cleanNickname(nick, fallback = 'Kabayan') {
  if (typeof nick !== 'string') return fallback;
  const t = nick.trim().slice(0, 16) || fallback;
  return NICK_RE.test(t) ? t : fallback;
}

export function cleanTeam(team) {
  return team === 'blue' ? 'blue' : team === 'red' ? 'red' : null;
}

const SPECIES = ['koala', 'fox', 'dog', 'cat', 'bunny', 'turtle'];
export function cleanSpecies(s) {
  s = String(s || '').toLowerCase().trim();
  return SPECIES.includes(s) ? s : SPECIES[Math.floor(Math.random() * SPECIES.length)];
}

export function clampPos(pos, half = 28) {
  return {
    x: Math.max(-half, Math.min(half, Number(pos?.x) || 0)),
    z: Math.max(-half, Math.min(half, Number(pos?.z) || 0))
  };
}

// Token-bucket per socket for spammy events.
export function makeRateLimiter(limit = 30, perMs = 1000) {
  let tokens = limit, last = Date.now();
  return function allow(n = 1) {
    const now = Date.now();
    const elapsed = now - last;
    tokens = Math.min(limit, tokens + (elapsed / perMs) * limit);
    last = now;
    if (tokens >= n) { tokens -= n; return true; }
    return false;
  };
}
